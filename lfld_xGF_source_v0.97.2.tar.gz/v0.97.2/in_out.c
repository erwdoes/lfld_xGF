
void calculate_xGF(mpz_t N, uint32_t c, uint32_t d, uint32_t m){ // m<32
    mpz_t aux;
    mpz_init(aux);
    mpz_ui_pow_ui(N,c,1<<m);
    mpz_ui_pow_ui(aux,d,1<<m);
    mpz_add(N,N,aux);
    if (((c==8)&&(d==1))||((c==1)&&(d==8))) {
        mpz_ui_pow_ui(aux,2,1<<m);
        mpz_add_ui(aux,aux,1);
        mpz_divexact(N,N,aux);
    } else if (((c&1)==1)&&((d&1)==1)) {
        mpz_tdiv_q_2exp(N,N,1); //divide by 2
    }
    mpz_clear(aux);
}

int compare_xGF(mpz_t k,uint64_t a,uint64_t b,uint64_t m,uint64_t ind){
    int r=0;
    if (m<10) {
        mpz_t xGF,x;
        mpz_inits(xGF,x,0);
        calculate_xGF(xGF,a,b,ind);
        mpz_set(x,k);
        mpz_mul_2exp(x,x,m);
        mpz_add_ui(x,x,1);
        r=(mpz_cmp(xGF,x)==0);
        mpz_clears(xGF,x,0);
    }
    return r;
}



uint64_t scale_adjust(uint64_t x){
 if (x>1000000000000000000ULL) x=1000000000000000ULL*(x/1000000000000000ULL);
   else if (x>1000000000000000ULL) x=1000000000000ULL*(x/1000000000000ULL);
   else if (x>1000000000000ULL) x=1000000000ULL*(x/1000000000ULL);
   else if (x>1000000000ULL) x=1000000ULL*(x/1000000ULL);
   else if (x>1000000ULL) x=1000ULL*(x/1000ULL);
   return x;
} 

uint64_t scale_adjust2(uint64_t x){
 if (x>1000000000000000000ULL) x=1000000000000ULL*(x/1000000000000ULL);
   else if (x>1000000000000000ULL) x=1000000000ULL*(x/1000000000ULL);
   else if (x>1000000000000ULL) x=1000000ULL*(x/1000000ULL);
   else if (x>1000000000ULL) x=1000ULL*(x/1000ULL);
   return x;
} 

void show_head(uint32_t nmin, uint32_t nmax, uint64_t kmin,uint64_t kmax){ 
    char kminstr[32], kmaxstr[32];
    kmin=scale_adjust2(kmin);
    kmax=scale_adjust2(kmax);
    if (verboseLevel & lvDETAILS) {
        fprintf(stdout,"---------------------------------------------------------\n");
        fprintf(stdout,"| Checking n = %u - %u, k = %s - %s\n",nmin,nmax,uint64_2_str(kminstr, kmin),uint64_2_str(kmaxstr, kmax));
        fprintf(stdout,"---------------------------------------------------------\n");
    }
    if (logLevel & lvDETAILS) {
        fprintf(logfile,"---------------------------------------------------------\n");
        fprintf(logfile,"| Checking n = %u - %u, k = %s - %s\n",nmin,nmax,uint64_2_str(kminstr, kmin),uint64_2_str(kmaxstr, kmax));
        fprintf(logfile,"---------------------------------------------------------\n");
        fflush(logfile);
    }    
}

void show_status(uint64_t kmin,uint64_t kmax, uint32_t nmax,uint64_t total,double time, double tax){ 
    char kminstr[32], kmaxstr[32],totalstr[32];
    kmin=scale_adjust2(kmin);
    kmax=scale_adjust2(kmax);
    total=scale_adjust(total);
    if (verboseLevel & lvRANGE)  {
        printf("Range: %u - %u, %s - %s (%s Ks) Time: %f sec Tax: %f K/s\n\n",nCurrent,nmax-1,uint64_2_str(kminstr, kmin),uint64_2_str(kmaxstr, kmax), uint64_2_str(totalstr, total), time, tax);
    }
    if (logLevel & lvRANGE)  {
        fprintf(logfile,"Range: %u - %u, %s - %s (%s Ks) Time: %f sec Tax: %f K/s\n\n",nCurrent,nmax-1,uint64_2_str(kminstr, kmin),uint64_2_str(kmaxstr, kmax), uint64_2_str(totalstr, total), time, tax);    
        fflush(logfile);
    }
}

void showETA(double ETA){
    char ETAstr[32];
    if (ETA<0) return;
    if (ETA<60) { //seconds
        sprintf(ETAstr,"%.2f sec",ETA);
    } else if (ETA<3600) {//minuts
        uint32_t min=(uint32_t) (ETA/60);
        sprintf(ETAstr,"%u m %.2f sec",min, ETA-60*min);
    } else if (ETA<86400) {//hours       
        uint32_t horas=(uint32_t)(ETA/3600), min;
        ETA=ETA-3600*horas;
        min=(uint32_t) (ETA/60);
        sprintf(ETAstr,"%u h %u m %.2f sec",horas,min, ETA-60*min);        
    } else { //days
        uint32_t dias=(uint32_t)(ETA/86400),horas, min;
        ETA=ETA-dias*86400;
        horas=(uint32_t)(ETA/3600);
        ETA=ETA-3600*horas;
        min=(uint32_t) (ETA/60);
        sprintf(ETAstr,"%u d %u h %u m %.2f sec",dias,horas,min, ETA-60*min);  
    }
    if (verboseLevel & lvETA) {
        printf("ETA: %s\n",ETAstr);
    }
    if (logLevel & lvETA) {
        fprintf(logfile,"ETA: %s\n",ETAstr);
        fflush(logfile);
    }
    
}

 
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
//   I/O
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////


void writeFactor(mpz_t k,uint64_t a,uint64_t b,uint64_t m,uint64_t ind, uint32_t prime_prp){
    FILE *factorFile;
    char name[200];
    uint8_t isxGF=compare_xGF(k,a,b,m,ind);
    // main
    sprintf(name,"%s.Factors",prefix);
    factorFile=fopen(name,"at");
    if (factorFile==NULL){
        fprintf(stderr,"Could not open file %s\n",name);
        exit(1);
    }
    showTime(factorFile);
    mpz_out_str(factorFile,10,k); 
    if (isxGF)  fprintf(factorFile, "*2^%lu+1 it's the same as xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    else if (prime_prp==2) fprintf(factorFile, "*2^%lu+1 Factor of xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    else fprintf(factorFile, "*2^%lu+1 probable Factor of xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    sync();
    fclose(factorFile);
    // backup
    sprintf(name,"bkp.%s.Factors",prefix);
    factorFile=fopen(name,"at");
    if (factorFile==NULL){
        fprintf(stderr,"Could not open file %s\n",name);
        exit(1);
    }
    showTime(factorFile);    
    mpz_out_str(factorFile,10,k); 
    if (isxGF)  fprintf(factorFile, "*2^%lu+1 it's the same as xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    else if (prime_prp==2) fprintf(factorFile, "*2^%lu+1 Factor of xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    else fprintf(factorFile, "*2^%lu+1 probable Factor of xGF(%lu,%lu,%lu)\n",m,ind,a,b);
    sync();
    fclose(factorFile);
    
    if (verboseLevel & lvFACTOR) {
       printf("\n============================================================\n");             
       if (isxGF)  gmp_printf("%Zd*2^%lu+1 it's the same as xGF(%lu,%lu,%lu)\n",k,m,ind,a,b);
       else if (prime_prp==2) gmp_printf("%Zd*2^%lu+1 Factor of xGF(%lu,%lu,%lu)\n",k,m,ind,a,b);             
       else  gmp_printf("%Zd*2^%lu+1 probable Factor of xGF(%lu,%lu,%lu)\n",k,m,ind,a,b);             
       printf("============================================================\n\n");            
       fflush(stdout);
    }
    
    if (logLevel & lvFACTOR) {
       fprintf(logfile,"\n============================================================\n");             
       mpz_out_str(logfile,10,k); 
       if (isxGF)  fprintf(logfile, "*2^%lu+1 it's the same as xGF(%lu,%lu,%lu)\n",m,ind,a,b);
       else if (prime_prp==2) fprintf(logfile,"*2^%lu+1 Factor of xGF(%lu,%lu,%lu)\n",m,ind,a,b);             
       fprintf(logfile,"============================================================\n\n");            
       fflush(logfile);
    }
}


void write_ini(const char *name,uint64_t k, uint32_t n){
    FILE *ini;    
    ini=fopen(name,"wt");
    if (ini==NULL){
        fprintf(stderr,"Can not create file %s\n",name);
        exit(1);
    }
    fprintf(ini,"device=%u\n",device);    
    fprintf_suffix(ini,"kStart=",kStart);fprintf(ini,"\n");
    fprintf_suffix(ini,"kCurrent=",k);fprintf(ini,"\n");
    fprintf_suffix(ini,"kEnd=",kEnd); fprintf(ini,"\n");   
    fprintf_suffix(ini,"kStep=",kStep);fprintf(ini,"\n");    
    fprintf(ini,"nStart=%u\n",nStart);
    fprintf(ini,"nCurrent=%u\n",n);
    fprintf(ini,"nEnd=%u\n",nEnd);    
    fprintf(ini,"nStep=%u\n",nStep);    
    if (!autopmax) {fprintf_suffix(ini,"pMax=",pMax); fprintf(ini,"\n");}    
    fprintf(ini,"order=%c\n",order);    
    fprintf(ini,"prefix=%s\n",prefix);    
    fprintf(ini,"verbose=%u\n",verboseLevel);    
    fprintf(ini,"log=%u\n",logLevel);    
    fprintf(ini,"debug=%u\n",debugLevel);    
    
    sync();
    fclose(ini);
}

void write_status(uint64_t k, uint32_t n){
    char bkp_name[1028];
    sprintf(bkp_name,"bkp.%s",inifilename);
    write_ini(bkp_name,k,n);
    write_ini(inifilename,k,n);
}

void interpret_line(const char *line,uint64_t tam){
    if (strncmp(line,"kStart=",7)==0) kStart=str_2_uint64(line+7);
    else if (strncmp(line,"kCurrent=",9)==0) kCurrent=str_2_uint64(line+9);
    else if (strncmp(line,"kEnd=",5)==0) kEnd=str_2_uint64(line+5);
    else if (strncmp(line,"kStep=",6)==0) kStep=str_2_uint64(line+6);
    else if (strncmp(line,"nStart=",7)==0) nStart=atoi(line+7);
    else if (strncmp(line,"nCurrent=",9)==0) nCurrent=atoi(line+9);
    else if (strncmp(line,"nEnd=",5)==0) nEnd=atoi(line+5);
    else if (strncmp(line,"nStep=",6)==0) nStep=atoi(line+6);
    else if (strncmp(line,"pMax=",5)==0) pMax=str_2_uint64(line+5);
    else if (strncmp(line,"device=",7)==0) device=atoi(line+7);
    else if (strncmp(line,"verbose=",8)==0) verboseLevel=atoi(line+8);
    else if (strncmp(line,"log=",4)==0) logLevel=atoi(line+4);
    else if (strncmp(line,"debug=",6)==0) debugLevel=atoi(line+6);
    else if (strncmp(line,"prefix=",7)==0) strncpy(prefix,line+7,127);
    else if (strncmp(line,"order=",6)==0) {
        order=*(line+6);
        if ((order!='k')&&(order!='K')&&(order!='n')&&(order!='N')) {
            fprintf(stderr,"order %c unknown\n",order);
            exit(1);
        }
    }
    else { 
        fprintf(stderr,"Option %s unknown in the INI file\n",line);
            exit(1);
        }
}

void read_ini(const char *name){
    FILE *ini;
    char buffer[1024];
    strncpy(inifilename,name,1023);
    ini=fopen(name,"rt");
    if (ini==NULL){
        fprintf(stderr,"Could not open file %s\n",name);
        exit(1);
    }
    while (!feof(ini)) {
        fgets(buffer,1024,ini);
        if (buffer[strlen(buffer)-1]=='\n') buffer[strlen(buffer)-1]=0; //erase newline
        interpret_line(buffer,1024);
    }    
    fclose(ini);        
}

void showFactorsFile(FILE *out){
    FILE *factorFile,*ntshow;
    char buffer[1024];
    int count=0,countNotShown;
    sprintf(buffer,"%s.Factors",prefix);
    factorFile=fopen(buffer,"rt");
    if (factorFile!=NULL){
       sprintf(buffer,"%s.nsh",prefix);
       ntshow=fopen(buffer,"rt");
       if (ntshow!=NULL){
           fscanf(ntshow,"%d",&countNotShown);
           fclose(ntshow);
       } else countNotShown=0;
       fprintf(out,"\n=======================================================================================\n");
       fprintf(out,"Factors Found:\n");
       if (countNotShown>0) fprintf(out,"     ...\n");
       while (!feof(factorFile)) {
          fgets(buffer,1024,factorFile);
          if (!feof(factorFile)) {
            count++; 
            if (count>countNotShown) fprintf(out,"%5d %s",count, buffer);
          }
       }    
       fprintf(out,"=======================================================================================\n\n");
       fclose(factorFile);        
    }  
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
//   DEBUG I/O
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

void save_sieve_prime_table(void){    
    uint8_t *h_SP;
    cudaError_t err = cudaSuccess;
    FILE  *sptFile;
    char name[200];
    h_SP=(uint8_t *) malloc(sieve_size*sizeof(uint8_t));
    if (h_SP==NULL) {
        fprintf(stderr, "Failed  allocation on host: sieve primes array\n");
        return;
    }
    
    err = cudaMemcpy(h_SP, d_SP, sieve_size*sizeof(uint8_t), cudaMemcpyDeviceToHost);
    if (err != cudaSuccess)     {
        fprintf(stderr, "Failed when copying from the device to the host: prime sieve table (error code %s)!\n", cudaGetErrorString(err));
        goto end_save;
    }   
    sprintf(name,"%s.spt",prefix);
    sptFile=fopen(name,"wt");
    if (sptFile==NULL){
        fprintf(stderr,"Can not create file lfld_xGF.spt\n");
    } else {
        uint64_t p=1;
        for (uint64_t i=0;i<sieve_size;i++) {
           uint8_t byte=h_SP[i];
           for (uint8_t j=0;j<8;j++) {
              if (byte&1) {
                  fprintf(sptFile,"%lu\n",p);
              }
              byte>>=1;
              p=p+2;
           }
        }
      fclose(sptFile);  
    }    
end_save:        
    free(h_SP);
}


void save_candidates(void){
    char name[200];
    uint8_t *h_kt;
    cudaError_t err = cudaSuccess;
    FILE  *ktFile;
    h_kt=(uint8_t *) malloc(sizeData*sizeof(uint8_t));
    if (h_kt==NULL) {
        fprintf(stderr, "Failed  allocation on host: candidates array\n");
        return;
    }
    
    for (uint32_t ni=0;ni<nStep;ni++) {
        if (ni+nCurrent>nEnd) break;
         err = cudaMemcpy(h_kt, hd_tab_data[ni], sizeData * sizeof(uint8_t), cudaMemcpyDeviceToHost);
         if (err != cudaSuccess)     {
             fprintf(stderr, "Failed when copying from the device to the host: candidates array (error code %s)!\n", cudaGetErrorString(err));
             goto end_save;
         }   
         sprintf(name,"%s.%.4u.%.10lu.kt",prefix,nCurrent+ni,kCurrent);
         ktFile=fopen(name,"wt");
         if (ktFile==NULL){
             fprintf(stderr,"Can not create file %s\n",name);
             goto end_save;
         } else {
             fprintf(ktFile,"%lu:P:1:2:1\n",pMaxLim);
             uint64_t k=kCurrent;
             for (uint64_t i=0;i<sizeData;i++) {
                uint8_t byte=h_kt[i];
                for (uint8_t j=0;j<8;j++) {
                   if (byte&1) {
                       fprintf(ktFile,"%lu %u\n",k,nCurrent+ni);
                   }
                   byte>>=1;
                   k=k+2;
                }
             }
           fclose(ktFile);  
         }    
    }
end_save:        
    free(h_kt);        
}

void save_head_ABC_file(const char *name){
    FILE *f;
    f=fopen(name,"rt");
    if (f==NULL) {  // not exist
       f=fopen(name,"wt");
       if (f==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(f,"ABC $a*2^$b+1\n");
    }
    fclose(f);
}    



