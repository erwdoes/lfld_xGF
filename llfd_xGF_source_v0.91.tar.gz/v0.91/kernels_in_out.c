
void save_fill_candidates_64(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint64tompz(x,cand_64[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_64(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint64tompz(x,cand_64[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_96(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint96tompz(x,cand_96[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_96(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint96tompz(x,cand_96[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_128(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint128tompz(x,cand_128[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_128(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint128tompz(x,cand_128[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_160(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint160tompz(x,cand_160[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_160(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint160tompz(x,cand_160[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_192(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint192tompz(x,cand_192[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_192(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint192tompz(x,cand_192[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_224(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint224tompz(x,cand_224[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_224(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint224tompz(x,cand_224[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_256(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint256tompz(x,cand_256[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_256(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint256tompz(x,cand_256[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_288(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint288tompz(x,cand_288[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_288(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint288tompz(x,cand_288[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_320(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint320tompz(x,cand_320[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_320(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint320tompz(x,cand_320[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_352(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint352tompz(x,cand_352[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_352(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint352tompz(x,cand_352[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_384(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint384tompz(x,cand_384[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_384(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint384tompz(x,cand_384[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
void save_fill_candidates_416(uint32_t m){
    char name[200];
    FILE *scFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.sc",prefix,m);
    scFile=fopen(name,"rt");
    if (scFile==NULL) {  // not exist
       scFile=fopen(name,"wt");
       if (scFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(scFile,"ABC $a*2^$b+1\n");
    }
    fseek(scFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t b=0;b<NUM_BLOCK_CAND;b++){
       for (uint32_t c=0;c<numCand[b];c++) {
     //     uint416tompz(x,cand_416[b][c]);
          mpz_fdiv_q_2exp(x,x,m);
          mpz_out_str(scFile,10,x);
          fprintf(scFile," %u\n",m);
       }
    }
    mpz_clear(x);
    fclose(scFile);
}
void save_check_candidates_416(uint32_t m){
    char name[200];
    FILE *sccFile;
    mpz_t x;
    
    sprintf(name,"%s.%.4u.scc",prefix,m);
    sccFile=fopen(name,"rt");
    if (sccFile==NULL) {  // not exist
       sccFile=fopen(name,"wt");
       if (sccFile==NULL){
           fprintf(stderr,"Can not create file %s\n",name);
           return;
       }
       fprintf(sccFile,"ABC $a*2^$b+1\n");
    }
    fseek(sccFile,0,SEEK_END);
    mpz_init(x);
    for (uint32_t j=0;j<numChecked;j++) {
     // uint416tompz(x,cand_416[checkedBlock[j]][checkedInd[j]]);
      mpz_fdiv_q_2exp(x,x,m);
      mpz_out_str(sccFile,10,x);
     // fprintf(sccFile," %u %lu %lu %lu %u\n",m,checkedBlock[j],numCand[checkedBlock[j]],checkedInd[j],j);
    }
    mpz_clear(x);
    fclose(sccFile);
}
