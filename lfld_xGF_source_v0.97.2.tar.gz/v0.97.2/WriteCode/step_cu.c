
void WriteRunStep(uint32_t ni,uint32_t ne) {
    FILE *f;
    char nameFile[128];
    sprintf(nameFile,"step.cu");    
    f=fopen(nameFile,"wt");
    if (f==NULL) {
        fprintf(stderr,"Can not create file %s\n",nameFile);
        exit(1);
    }   
          //    init_run_step
    
    
fprintf(f,"void run_step(uint64_t kmax,uint32_t nmax){\n");
fprintf(f,"    mpz_t cand;\n");
fprintf(f,"    double tStep=0, tSieve=0, tFillCand=0, tPRP=0, tEliminate=0,tRegroup=0, txGF=0, tChecked=0, tTest=0;\n");
fprintf(f,"    uint64_t numCandTested=0;\n");
fprintf(f,"    uint64_t checked=0;\n");
fprintf(f,"    uint64_t numPRP,numRegroupBlocks,rest;\n");
fprintf(f,"    uint8_t showTime=((verboseLevel|logLevel) & (lvTIME|lvXGF|lvRANGE));\n");
fprintf(f,"\n");
fprintf(f,"    mpz_init(cand);\n");
fprintf(f,"\n");
fprintf(f,"    if ((verboseLevel|logLevel) & lvDETAILS) show_head(nCurrent, nmax-1, kCurrent,kmax);\n");
fprintf(f,"    if (showTime) tStep=tSieve=getTime();\n");
fprintf(f,"\n");
fprintf(f,"    if (autopmax) pMax=choose_pmax(kmax,nmax);\n");
fprintf(f,"\n");
fprintf(f,"    //sieve candidates with primes 3..pMax\n");
fprintf(f,"    sieve_candidates(nmax);\n");
fprintf(f,"\n");
fprintf(f,"    if (showTime) {\n");
fprintf(f,"      tTest=getTime();\n");
fprintf(f,"      tSieve=tTest-tSieve;\n");
fprintf(f,"    }\n");
fprintf(f,"    if (debugLevel&lvCANDIDATES) save_candidates();\n");
fprintf(f,"\n");
fprintf(f,"    init_va_gmp();\n");
fprintf(f,"\n");
fprintf(f,"    if (verboseLevel & lvDETAILS) fprintf(stderr,\"find factors for \"); \n");
fprintf(f,"\n");
fprintf(f,"    for (uint64_t n=nCurrent;n<nmax;n++) {\n");
fprintf(f,"        uint8_t tested=0;\n");
fprintf(f,"        for (uint64_t jb=0;jb<NUM_BLOCK_CAND;jb++) kind[jb]=kCurrent;\n");
fprintf(f,"\n");
fprintf(f,"        //choose the appropriate kernel\n");
fprintf(f,"        choose_kernel(kmax,n);\n");
fprintf(f,"\n");
fprintf(f,"        if (verboseLevel & lvDETAILS) fprintf(stderr,\"M=%%lu (%%u bits kernel) \",n,abs(kernel));\n");
fprintf(f,"\n");
fprintf(f,"        if (logLevel & lvDETAILS) {\n");
fprintf(f,"            fprintf(logfile,\"M=%%lu (%%u bits kernel) \",n,abs(kernel));\n");
fprintf(f,"            fflush(logfile);\n");
fprintf(f,"        }\n");
fprintf(f,"\n");
fprintf(f,"        do {\n");
fprintf(f,"            cudaError_t err;\n");
fprintf(f,"            numChecked=0;\n");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//switch_fill_cand
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"\n            // fill candidates array\n");
fprintf(f,"            tFillCand-=getTime();\n");
fprintf(f,"            switch (kernel) {\n");

for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"                  case %u: fill_cand_%u<<<NUM_BLOCK_CAND,1>>>(n-nCurrent); break;\n",n,n);
    
fprintf(f,"                  default: fprintf(stderr,\"\\nkernel fill_cand %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"            } //switch\n");
fprintf(f,"            err = cudaGetLastError();\n");
fprintf(f,"            if (err != cudaSuccess)     {\n");
fprintf(f,"              fprintf(stderr, \"Failed to launch fill_cand_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"              exit(EXIT_FAILURE);\n");
fprintf(f,"            }\n");        
fprintf(f,"            cudaDeviceSynchronize();\n");
fprintf(f,"            err = cudaGetLastError();\n");
fprintf(f,"            if (err != cudaSuccess)     {\n");
fprintf(f,"               fprintf(stderr, \"Failed cudaDeviceSynchronize fill_cand_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"               exit(EXIT_FAILURE);\n");
fprintf(f,"            }\n");                                
fprintf(f,"            tFillCand+=getTime();\n");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_save_fill
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"            if (debugLevel&lvFILL)\n");
fprintf(f,"              switch (kernel) {\n");

for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"                 case %u: save_fill_candidates_%u(n); break;\n",n,n);

fprintf(f,"                 default: fprintf(stderr,\"\\nkernel save_fill_candidates %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"              } //switch\n");


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_prp_test
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"\n            if (kernel>=THRESHOLD_PRP) { //does not perform PRP test for kernel with less THRESHOLD_PRP bits\n");
fprintf(f,"              // test prp of the candidates\n");
fprintf(f,"              tPRP-=getTime();\n");
fprintf(f,"              switch (kernel) {\n");
for (uint32_t n=ni;n<=ne;n+=32) 
    fprintf(f,"                 case %u: prp_test_%u<<<NUM_BLOCK_CAND,SizeBlockCand_%u>>>(n); break;\n",n,n,n);    
     

fprintf(f,"                 default: fprintf(stderr,\"\\nkernel prp_test %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"              } //switch\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                fprintf(stderr, \"Failed to launch prp_test_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                exit(EXIT_FAILURE);\n");
fprintf(f,"               }\n");        
fprintf(f,"              cudaDeviceSynchronize();\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                 fprintf(stderr, \"Failed cudaDeviceSynchronize prp_test_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                 exit(EXIT_FAILURE);\n");
fprintf(f,"              }\n");
fprintf(f,"              tPRP+=getTime();\n");




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_eliminate composite
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"\n              // eliminate composite candidates \n");
fprintf(f,"              tEliminate-=getTime();\n");
fprintf(f,"              switch (kernel) {\n");

for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"               case %u: eliminate_composite_%u<<<NUM_BLOCK_CAND,1>>>(); break;\n",n,n,n);
    
fprintf(f,"                 default: fprintf(stderr,\"\\nkernel eliminate_composite %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"              } //switch\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                fprintf(stderr, \"Failed to launch eliminate_composite_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                exit(EXIT_FAILURE);\n");
fprintf(f,"               }\n");        
fprintf(f,"              cudaDeviceSynchronize();\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                 fprintf(stderr, \"Failed cudaDeviceSynchronize eliminate_composite_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                 exit(EXIT_FAILURE);\n");
fprintf(f,"              }\n");
fprintf(f,"              tEliminate+=getTime();\n");


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_regroup candidates
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"\n              // regroup candidates \n");
fprintf(f,"              tRegroup-=getTime();\n");
fprintf(f,"              numPRP=0;\n");
fprintf(f,"              numRegroupBlocks=0;\n");
fprintf(f,"              for (uint64_t jb=0;jb<NUM_BLOCK_CAND;jb++) {\n");
fprintf(f,"                 numPRP+=numCand[jb];\n");
fprintf(f,"              }\n");
fprintf(f,"              if (numPRP>0) {\n");
fprintf(f,"                do{\n");
fprintf(f,"                  switch (kernel) {\n");
for (uint32_t n=ni;n<=ne;n+=32) {
   fprintf(f,"                     case %u: numRegroupBlocks=10+((numPRP+SizeBlockCand_%u-1)/SizeBlockCand_%u);\n",n,n,n);
   fprintf(f,"                              if(numRegroupBlocks>NUM_BLOCK_CAND) numRegroupBlocks=NUM_BLOCK_CAND ;\n");
   fprintf(f,"                              nextRegroupBlock=numRegroupBlocks+1;\n");
//    fprintf(f,"                              fprintf(stderr,\"NumregBlocks=%%lu nextRegroupBlock= %%u Size=%%u\",numRegroupBlocks,nextRegroupBlock,SizeBlockCand_%u);\n",n);   
   fprintf(f,"                              regroup_candidates_%u<<<numRegroupBlocks,1>>>(); break;\n",n,n);
}

fprintf(f,"                     default: fprintf(stderr,\"\\nkernel regroup_candidates %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"                  } //switch\n");
fprintf(f,"                  err = cudaGetLastError();\n");
fprintf(f,"                  if (err != cudaSuccess)     {\n");
fprintf(f,"                    fprintf(stderr, \"Failed to launch regroup_candidates_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                    exit(EXIT_FAILURE);\n");
fprintf(f,"                   }\n");        
fprintf(f,"                  cudaDeviceSynchronize();\n");
fprintf(f,"                  err = cudaGetLastError();\n");
fprintf(f,"                  if (err != cudaSuccess)     {\n");
fprintf(f,"                     fprintf(stderr, \"Failed cudaDeviceSynchronize regroup_candidates_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                     exit(EXIT_FAILURE);\n");
fprintf(f,"                  }\n");
fprintf(f,"                  rest=0;\n");
fprintf(f,"                  for (uint64_t jb=numRegroupBlocks+2;jb<NUM_BLOCK_CAND;jb++) {\n");
fprintf(f,"                    rest+=numCand[jb];\n");
// fprintf(f,"                    if (numCand[jb]>0)  fprintf(stderr, \" rest=%%lu %%lu %%lu\\n\",rest,numCand[jb],jb);\n");
fprintf(f,"                   }\n");
// fprintf(f,"                     fprintf(stderr, \" rest=%%lu\\n\",rest);\n");
fprintf(f,"                 } while (rest>0);\n");
fprintf(f,"               }// if(numPRP)\n");
fprintf(f,"              tRegroup+=getTime();\n");

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_save_prp
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"              if (debugLevel&lvPRP)\n");
fprintf(f,"              switch (kernel) {\n");
                  
for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"                 case %u: save_prp_candidates_%u(n); break;\n",n,n);

fprintf(f,"                 default: fprintf(stderr,\"\\nkernel save_prp_candidates %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"              } //switch\n");


fprintf(f,"           } else { //if (kernel>=THRESHOLD_PRP)\n");
fprintf(f,"             numRegroupBlocks=NUM_BLOCK_CAND;\n");
fprintf(f,"             numPRP=0;\n");
fprintf(f,"              for (uint64_t jb=0;jb<NUM_BLOCK_CAND;jb++) {\n");
fprintf(f,"                 numPRP+=numCand[jb];\n");
fprintf(f,"              }\n");
fprintf(f,"           }//if (kernel>=THRESHOLD_PRP)\n");


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// switch_xGF_cand
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

fprintf(f,"            if (numPRP>0) {\n");
fprintf(f,"\n              // test candidates\n");
fprintf(f,"              txGF-=getTime();\n");
fprintf(f,"              switch (kernel) {\n");


for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"                 case %u: xGF_%u<<<numRegroupBlocks,SizeBlockCand_%u>>>(n); break;\n",n,n,n);
//    fprintf(f,"               case %u: xGF_%u<<<NUM_BLOCK_CAND,SizeBlockCand_%u>>>(n); break;\n",n,n,n);
    
fprintf(f,"                 default: fprintf(stderr,\"\\nkernel xGF %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"              } //switch\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                fprintf(stderr, \"Failed to launch xGF_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                exit(EXIT_FAILURE);\n");
fprintf(f,"               }\n");        
fprintf(f,"              cudaDeviceSynchronize();\n");
fprintf(f,"              err = cudaGetLastError();\n");
fprintf(f,"              if (err != cudaSuccess)     {\n");
fprintf(f,"                 fprintf(stderr, \"Failed cudaDeviceSynchronize xGF_%%u kernel (error code %%s)!\\n\", kernel, cudaGetErrorString(err));\n");
fprintf(f,"                 exit(EXIT_FAILURE);\n");
fprintf(f,"              }\n");
fprintf(f,"              txGF+=getTime();\n");
fprintf(f,"           }// if(numPRP)\n");

//  switch_save_check
fprintf(f,"            if (debugLevel&lvCHECKED)\n");
fprintf(f,"              switch (kernel) {\n");

for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"                  case %u: save_check_candidates_%u(n); break;\n",n,n);


fprintf(f,"                  default: fprintf(stderr,\"\\nkernel save_check_candidates %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"            } //switch\n");

 
// switch_uinttompz()
fprintf(f,"\n");
fprintf(f,"           // verifies candidates marked\n");
fprintf(f,"           tChecked-=getTime();\n");
fprintf(f,"           for (uint64_t jb=0;jb<NUM_BLOCK_CAND;jb++) {\n");
fprintf(f,"             numCandTested+=numCand[jb];\n");
fprintf(f,"           }\n");
fprintf(f,"           for (uint32_t j=0;j<numChecked;j++) {\n");
fprintf(f,"             switch (kernel) {\n");                         

for (uint32_t n=ni;n<=ne;n+=32) 
   fprintf(f,"               case %u: uint%utompz(cand,checkCand_%u[j]); break;\n",n,n,n);
           
fprintf(f,"               default: fprintf(stderr,\"\\nkernel uinttompz %%d bits unavailable\\n\",-kernel); exit(1);\n");
fprintf(f,"             } //switch\n");
fprintf(f,"             uint32_t test=prime_or_prp(cand);\n");
fprintf(f,"             if (test) test_xGF_power_gmp(cand,test);\n");
fprintf(f,"             checked++;\n");
fprintf(f,"           }\n");
fprintf(f,"           tChecked+=getTime();\n");

// end_run_step

fprintf(f,"           // Check for all candidates tested\n");
fprintf(f,"           tested=1;\n");
fprintf(f,"           for (uint64_t jb=0;jb<NUM_BLOCK_CAND;jb++) {\n");
fprintf(f,"               tested=(tested)&&(numCand[jb]==0);\n");
fprintf(f,"               if (!tested) break;\n");
fprintf(f,"           } //for jb\n");
fprintf(f,"        } while (!tested);\n");        
fprintf(f,"    } //for n\n");
    
fprintf(f,"    if (verboseLevel & lvDETAILS) fprintf(stderr,\"\\n\");\n");
fprintf(f,"    if (logLevel & lvDETAILS) { \n");
fprintf(f,"        fprintf(logfile,\"\\n\");\n");
fprintf(f,"        fflush(logfile);\n");
fprintf(f,"    }\n");
fprintf(f,"\n");
fprintf(f,"    free_va_gmp();\n");
    
fprintf(f,"    if (showTime) {\n");
fprintf(f,"       tTest=getTime()-tTest;\n");
fprintf(f,"       tStep=getTime()-tStep;\n");
fprintf(f,"    }\n");
fprintf(f,"\n");
fprintf(f,"    if (verboseLevel & lvXGF) printf(\"Tested %%lu candidates in %%f sec (%%f us/Test) checked: %%lu\\n\",numCandTested, tTest, 1000000*tTest/numCandTested, checked);\n");
fprintf(f,"\n");
fprintf(f,"    if (logLevel & lvXGF) {\n");
fprintf(f,"        fprintf(logfile,\"Tested %%lu candidates in %%f sec (%%f us/Test) checked: %%lu\\n\",numCandTested, tTest, 1000000*tTest/numCandTested, checked);\n");
fprintf(f,"        fflush(logfile);\n");
fprintf(f,"    }\n");
fprintf(f,"    uint64_t qtyK=(nmax-nCurrent)*(kmax-kCurrent);\n");
fprintf(f,"\n");
fprintf(f,"    if ((verboseLevel|logLevel) & lvRANGE) show_status(kCurrent,kmax,nmax, qtyK, tStep,qtyK/tStep);\n");
fprintf(f,"\n");
fprintf(f,"    if (verboseLevel & lvTIME) fprintf(stderr,\"TSieve= %%.2f TFill= %%.2f TPRP= %%.2f TElim= %%.2f TRegr= %%.2f TxGF= %%.2f TChecked= %%.2f\\n\",tSieve,tFillCand,tPRP, tEliminate,tRegroup, txGF, tChecked);\n");
fprintf(f,"\n");
fprintf(f,"    if (logLevel & lvTIME) {\n");
fprintf(f,"        fprintf(logfile,\"TSieve= %%.2f TFill= %%.2f TPRP= %%.2f TElim= %%.2f TxGF= %%.2f TRegr= %%.2f TChecked= %%.2f\\n\", tSieve, tFillCand, tPRP,  tEliminate, tRegroup, txGF, tChecked);\n");
fprintf(f,"        fflush(logfile);\n");
fprintf(f,"    }\n");
fprintf(f,"\n");
fprintf(f,"    if (verboseLevel & lvFACTOR) showFactorsFile(stdout);\n");
fprintf(f,"\n");
fprintf(f,"    fflush(stdout);\n");
fprintf(f,"\n");
fprintf(f,"    mpz_clear(cand);\n");
fprintf(f,"}\n");




    fclose(f);
}    
