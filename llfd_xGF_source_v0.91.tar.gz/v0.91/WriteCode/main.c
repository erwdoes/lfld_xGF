#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define N_MAX  100
#define DN_MAX N_MAX<<1

uint32_t ops[DN_MAX][DN_MAX];  //operando superior
uint32_t opi[DN_MAX][DN_MAX];  //operando inferior
uint8_t HL[DN_MAX][DN_MAX];  // 1=high  0=low
uint32_t DN,N,nw;


void zera(void){
   uint32_t i,j;
   for (i=0;i<DN_MAX;i++) 
       for (j=0;j<DN_MAX;j++) {
         ops[i][j]=0;
         opi[i][j]=0;
         HL[i][j]=0;
       }
}


uint32_t linha_vazia(uint32_t pos, uint32_t max){
   uint32_t lin;
      lin=0; 
      while ((lin<=max)&& ((ops[pos][lin]+ops[pos+1][lin])!=0)) lin++;
      return lin;
}


void gera_linha(uint32_t ni){
   uint32_t linha=2*ni+1; 
   int sinal;
   for (uint32_t j=0;j<N;j++) {
     uint32_t pos=ni+j;        
     uint32_t lindest=linha_vazia(pos,linha);
     ops[pos][lindest]=DN+N+j+1;
     opi[pos][lindest]=DN+ni+1;
     ops[pos+1][lindest]=DN+N+j+1;
     opi[pos+1][lindest]=DN+ni+1;
     HL[pos+1][lindest]=1;     
   }
}

void marca_primeiro_ultimo(void){
   for (uint32_t i=0;i<DN;i++) {
      uint32_t j=0;
      while ((j<DN)&&(ops[j][i]==0)) j++;
      if (j<DN) HL[j][i]|=2; // marca como primeiro
      j=N<<1;
      while ((j>0)&&(ops[j-1][i]==0)) j--;
      if (j>0) HL[j-1][i]|=4; // marca como ultimo
   }
  for (uint32_t j=0;j<DN;j++) {      
    if (ops[j][0]!=0) HL[j][0]|=8; // marca como primeiro da coluna na primeira linha
    uint32_t i=0;
    while ((i<DN) && (ops[j][i]==0)) i++;
    if ((i<DN)&&((HL[j][i]&1)==0)) HL[j][i]|=8; // marca como primeiro da coluna apenas L
      
  }
}

void mostra_mult(uint32_t Lim, uint8_t square) {    
    printf("// registers map\n\n");
    printf("//        |");
    if (square) for(uint32_t j=0;j<N;j++) printf("  %3u  |",Lim+N-j-1);  
    else for(uint32_t j=0;j<N;j++) printf("  %3u  |",Lim+DN-j-1);     
    printf("\n");
    printf("//      X |");
    for(uint32_t j=0;j<N;j++) printf("  %3u  |",Lim+N-j-1);     
    printf("\n\n");
    printf("// |");
    for (uint32_t j=0;j<Lim;j++) printf("      %3u        |",Lim-j-1);
    printf("\n// |");
    for (uint32_t j=0;j<Lim;j++) printf("=================|");
    printf("\n");
    for (uint32_t i=0;i<DN;i++) {
        uint32_t soma=0;        
        for (uint32_t j=0;j<Lim;j++) soma+=ops[j][i];
        if (soma>0) {
            printf("// | ");
            for (uint32_t j=Lim;j>=1;j--) {
                if (ops[j-1][i]>0) {
                    printf("(%3u,%3u).",ops[j-1][i]-1,opi[j-1][i]-1);
                    if (HL[j-1][i]&1) printf("H [%X] | ",HL[j-1][i]); else printf("L [%X] | ",HL[j-1][i]);
                  } else printf("                | ");
            }
            printf("\n");
        }
    }
   printf("\n");
}

void ins_asm(void) {
    printf("     asm(\"\\n\\t\"\n");
}

void ins_mulhi(char *dest,char *op1, char *op2){
  printf("         \"mul.hi.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_mullo(char *dest,char *op1, char *op2){
  printf("         \"mul.lo.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_madchi(char *dest,char *op1, char *op2, char *op3){
  printf("         \"madc.hi.u32    %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madhi(char *dest,char *op1, char *op2, char *op3){
  printf("         \"mad.hi.u32     %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madclo(char *dest,char *op1, char *op2, char *op3){
  printf("         \"madc.lo.u32    %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madlo(char *dest,char *op1, char *op2, char *op3){
  printf("         \"mad.lo.u32     %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}


void ins_madchicc(char *dest,char *op1, char *op2, char *op3){
 printf("         \"madc.hi.cc.u32 %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madclocc(char *dest,char *op1, char *op2, char *op3){
 printf("         \"madc.lo.cc.u32 %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madhicc(char *dest,char *op1, char *op2, char *op3){
 printf("         \"mad.hi.cc.u32  %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madlocc(char *dest,char *op1, char *op2, char *op3){
 printf("         \"mad.lo.cc.u32  %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_addc(char *dest,char *op1, char *op2){
 printf("         \"addc.u32       %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_addccc(char *dest,char *op1, char *op2){
 printf("         \"addc.cc.u32    %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_addcc(char *dest,char *op1, char *op2){
 printf("         \"add.cc.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}


void ins_registers_mult(void) {
 printf("\n         : ");
 for (uint32_t i=0;i<N;i++) printf(" \"=r\" (lo->b%u),",i);
 printf("\n          ");
 for (uint32_t i=0;i<N-1;i++) printf(" \"=r\" (hi->b%u),",i);
 printf(" \"=r\" (hi->b%u)\n         : ",N-1);
 for (uint32_t i=0;i<N;i++) printf(" \"r\" (x.b%u),",i);
 printf("\n          ");
 for (uint32_t i=0;i<N-1;i++) printf(" \"r\" (y.b%u),",i);
 printf(" \"r\" (y.b%u));\n",N-1);
}


// uint32_t print_operacao_coluna_ocupada(uint32_t i, uint32_t j, uint32_t Limite, uint8_t *status_col,uint32_t carry,uint64_t *cadd, uint64_t *cmult) {
//     char opdest[5],opdestp[5],op1[5],op2[5];
//     sprintf(opdest,"%%%u",j);
//     sprintf(opdestp,"%%%u",j+1);
//     sprintf(op1,"%%%u",ops[j][i]-1);
//     sprintf(op2,"%%%u",opi[j][i]-1);
//     if (carry) { //com carry 
//         if (HL[j][i]&4) { // último da linha
//             if (j<Limite-1) {
//                  if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,opdest); else  ins_madclocc(opdest,op1,op2,opdest);
//                  if (status_col[j+1]==0) ins_addc(opdestp,"0","0"); else ins_addc(opdestp,opdestp,"0");
//                    (*cadd)++;
//                    status_col[j+1]++;                 
//             } else {
//                 if (HL[j][i]&1) ins_madchi(opdest,op1,op2,opdest); else ins_madclo(opdest,op1,op2,opdest);                       
//             }
//         } else { // não é o último da linha
//            if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,opdest); else  ins_madclocc(opdest,op1,op2,opdest); 
//         }
//         (*cmult)++;
//     } else { //sem carry
//         if (HL[j][i]&4) { // último da linha
//             if (j<Limite-1) {
//                  if (HL[j][i]&1) ins_madhicc(opdest,op1,op2,opdest); else  ins_madlocc(opdest,op1,op2,opdest);
//                  if (status_col[j+1]==0) ins_addc(opdestp,"0","0"); else ins_addc(opdestp,opdestp,"0");
//                    (*cadd)++;
//                    status_col[j+1]++;                 
//             } else {
//                 if (HL[j][i]&1) ins_madhi(opdest,op1,op2,opdest); else ins_madlo(opdest,op1,op2,opdest);                       
//             }
//         } else {// não é o último da linha
//              if (HL[j][i]&1) ins_madhicc(opdest,op1,op2,opdest); else  ins_madlocc(opdest,op1,op2,opdest);
//              carry=1;
//         }
//         (*cmult)++;
//     }    
//     return carry;    
// }

uint32_t print_operacao_coluna_ocupada(uint32_t i, uint32_t j, uint32_t Limite, uint8_t *status_col,uint32_t carry,uint64_t *cadd, uint64_t *cmult) {
    char opdest[5],opdestp[5],op1[5],op2[5];
    sprintf(opdest,"%%%u",j);
    sprintf(opdestp,"%%%u",j+1);
    sprintf(op1,"%%%u",ops[j][i]-1);
    sprintf(op2,"%%%u",opi[j][i]-1);
    if (carry) { //com carry 
        if (HL[j][i]&4) { // último da linha            
            if (j==Limite-1) {
                if (HL[j][i]&1) ins_madchi(opdest,op1,op2,opdest); else ins_madclo(opdest,op1,op2,opdest);
            } else if (j==Limite-2) {
                if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,opdest); else  ins_madclocc(opdest,op1,op2,opdest);
                 if (status_col[j+1]==0) ins_addc(opdestp,"0","0"); else ins_addc(opdestp,opdestp,"0");
                   (*cadd)++;
                   status_col[j+1]|=2; //ocupado com adição
            } else {
                if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,opdest); else ins_madclocc(opdest,op1,op2,opdest);
                uint32_t k=j+1;
                while ((k<Limite-1) && (status_col[k]==1) && (status_col[k+1])==1) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addccc(opdestp,opdestp,"0");
                    (*cadd)++;
                    k++;
                }
                if (status_col[k]==1) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addc(opdestp,opdestp,"0");
                    (*cadd)++;
                    if (k<Limite-1) {
                        sprintf(opdestp,"%%%u",k+1);
                        ins_addc(opdestp,"0","0"); 
                        status_col[k+1]|=2;
                        (*cadd)++;
                    }
                } else {
                    sprintf(opdestp,"%%%u",k);
                    if (status_col[k]==2) ins_addc(opdestp,opdestp,"0"); else ins_addc(opdestp,"0","0");
                    status_col[k]|=2;
                    (*cadd)++;
                }
            }
        } else { // não é o último da linha
           if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,opdest); else  ins_madclocc(opdest,op1,op2,opdest); 
        }
        (*cmult)++;
    } else { //sem carry
        if (HL[j][i]&4) { // último da linha
            
            if (j==Limite-1) {
                if (HL[j][i]&1) ins_madhi(opdest,op1,op2,opdest); else ins_madlo(opdest,op1,op2,opdest);
            } else if (j==Limite-2) {
                if (HL[j][i]&1) ins_madhicc(opdest,op1,op2,opdest); else  ins_madlocc(opdest,op1,op2,opdest);
                 if (status_col[j+1]==0) ins_addc(opdestp,"0","0"); else ins_addc(opdestp,opdestp,"0");
                   (*cadd)++;
                   status_col[j+1]++;                 
            } else {
                if (HL[j][i]&1) ins_madhicc(opdest,op1,op2,opdest); else ins_madlocc(opdest,op1,op2,opdest);
                uint32_t k=j+1;
                while ((k<Limite-1) && (status_col[k]==1) && (status_col[k+1]==1)) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addccc(opdestp,opdestp,"0");
                    (*cadd)++;
                    k++;
                }
                sprintf(opdestp,"%%%u",k);
                ins_addc(opdestp,opdestp,"0");
                (*cadd)++;
                if (k<Limite-1) {
                   sprintf(opdestp,"%%%u",k+1);
                   ins_addc(opdestp,"0","0"); 
                   (*cadd)++;
                   status_col[k]|=2;
                }
            }
        } else {// não é o último da linha
             if (HL[j][i]&1) ins_madhicc(opdest,op1,op2,opdest); else  ins_madlocc(opdest,op1,op2,opdest);
             carry=1;
        }
        (*cmult)++;
    }    
    return carry;    
}

uint32_t print_operacao_coluna_livre(uint32_t i, uint32_t j, uint32_t Limite, uint8_t *status_col,uint32_t carry,uint64_t *cadd, uint64_t *cmult) {
    char opdest[5],opdestp[5],op1[5],op2[5];
    sprintf(opdest,"%%%u",j);
    sprintf(opdestp,"%%%u",j+1);
    sprintf(op1,"%%%u",ops[j][i]-1);
    sprintf(op2,"%%%u",opi[j][i]-1);
    if (carry) {
        if (HL[j][i]&4) { // último da linha
           if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,"0"); else ins_madclocc(opdest,op1,op2,"0"); 
            carry=0;
            if (j<Limite-1) {
                uint32_t k=j+1;
                if (status_col[j+1]==0) ins_addc(opdestp,"0","0"); else ins_addc(opdestp,opdestp,"0");
                (*cadd)++;
                status_col[j+1]|=2;
            }
        } else {
            if (HL[j][i]&1) ins_madchicc(opdest,op1,op2,"0"); else ins_madclocc(opdest,op1,op2,"0"); 
        }
    } else {
        if (HL[j][i]&1) ins_mulhi(opdest,op1,op2); else ins_mullo(opdest,op1,op2);
    }
    status_col[j]|=1;
    (*cmult)++;
    return carry;
}

void gera_asm_mult(uint32_t Limite) {
    uint64_t cmult=0,cadd=0;
    uint8_t status_col[DN];
    for (uint32_t j=0;j<DN;j++) status_col[j]=0;
    for (uint32_t i=0;i<DN;i++) {
        uint32_t soma=0;
        uint8_t carry=0;
        for (uint32_t j=0;j<Limite;j++) soma+=ops[j][i];
        if (soma==0) continue;
        printf("\n");
        for (uint32_t j=0;j<Limite;j++) {
            if (ops[j][i]>0) {                
                if (status_col[j]==0) { // não existe valor anterior na coluna
                    carry=print_operacao_coluna_livre(i,j,Limite,status_col,carry,&cadd,&cmult);
                } else {  //coluna tem valor anterior
                    carry=print_operacao_coluna_ocupada(i,j,Limite,status_col,carry,&cadd,&cmult);
                }
            }
        }
    }
    printf("\n             // %lu additions and %lu multiplications\n",cadd,cmult);
}

void inverte_mult(void){
    for (uint32_t i=0;i<N-1;i++) {
      for (uint32_t j=0;j<DN;j++) {
          uint32_t aux;
          
          aux=ops[j][i];
          ops[j][i]=ops[j][DN-i-2];
          ops[j][DN-i-2]=aux;
          
          aux=opi[j][i];
          opi[j][i]=opi[j][DN-i-2];
          opi[j][DN-i-2]=aux;

          aux=HL[j][i];
          HL[j][i]=HL[j][DN-i-2];
          HL[j][DN-i-2]=(uint8_t)aux;
      }
        
    }
}


void gera_mult(void){
   zera();
   for (uint32_t i=0;i<N;i++)  gera_linha(i);
   inverte_mult();
   printf("// multiplication %u bits X %u bits => %u bits\n",nw,nw,nw<<1);
   mostra_mult(DN,0);   
   marca_primeiro_ultimo();
   printf("__device__ void mul_%u_%u(bt_uint%u_t *hi, bt_uint%u_t *lo,bt_uint%u_t x, bt_uint%u_t y){\n",nw,nw<<1,nw,nw,nw,nw);
   ins_asm();
   gera_asm_mult(DN);
   ins_registers_mult();
   printf("}\n\n"); //fim  da função
}


void gera_tipo_base_cabecalho(void) {
    
    printf("typedef union  __align__(16) {//basic type %u bits\n",nw);
    printf("     uint32_t v[%u];\n",N);   
    printf("     struct {uint32_t ");
    for (uint32_t i=0;i<N-1;i++) printf("b%u,",i);
    printf("b%u;};\n",N-1);
    printf("} bt_uint%u_t;\n\n",nw);

    printf("__device__ bt_uint%u_t cand_%u[NUM_BLOCK_CAND][SIZE_BLOCK_CAND]; //array candidates %u bits on device\n\n",nw,nw,nw);

    printf("__device__ __managed__ bt_uint%u_t checkCand_%u[MAX_CHECKED]; //array marked candidates %u bits on device\n\n",nw,nw,nw);
    
    printf("/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    printf("/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    printf("//   %u-bit arithmetic device codes \n",nw);
    printf("/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    printf("/////////////////////////////////////////////////////////////////////////////////////////////////////\n\n");
    
}

void print_regs(char tipo,char *ident){
   if (tipo==' ') {  
      for (uint32_t i=0;i<N-1;i++) printf("\"r\"(%s.b%u), ",ident,i);
      printf("\"r\"(%s.b%u)",ident,N-1);    
   } else {
      for (uint32_t i=0;i<N-1;i++) printf("\"%cr\"(%s.b%u), ",tipo,ident,i);
      printf("\"%cr\"(%s.b%u)",tipo,ident,N-1);    
   }
}

void gera_kn_bt(void){
    printf("__device__ bt_uint%u_t kn_bt%u(uint64_t k,uint32_t m) {\n",nw,nw);
    printf("     bt_uint%u_t res={",nw); 
    for (uint32_t i=1;i<N;i++) printf("0,");
    printf("0};\n");
    printf("     uint32_t w=(m>>5);  // w=m/32\n");
    printf("     if (w<%u) {\n",N-1);
    printf("         res.v[w]=(uint32_t)(k&0xFFFFFFFF);\n");          
    printf("         res.v[w+1]=(uint32_t)(k>>32);\n");
    printf("     } else {\n");
    printf("         res.b%u=(uint32_t)(k&0xFFFFFFFF);\n",N-1);
    printf("     }\n");
    printf("     m=m-(w<<5);\n");
    printf("     asm (\"\\n\\t\"\n");
    for (uint32_t i=N-1;i>0;i--)  printf("          \"shf.l.clamp.b32 %%%u, %%%u, %%%u, %%%u;\\n\\t\"\n",i,i-1,i,N);    
    printf("          \"shl.b32 %%0, %%0, %%%u;\\n\\t\"\n",N);     
    printf("          \"add.u32 %%0, %%0, 1;\\n\\t\"\n");    
//     printf("          \"}\"\n");
    printf("          : ");
    print_regs('+',"res");
    printf("\n          : \"r\"(m));\n");    
    printf("      return res;\n}\n\n");
}


void gera_add_uint(void) {
    printf("__device__ bt_uint%u_t add_uint%u (bt_uint%u_t a, bt_uint%u_t b) {\n",nw,nw,nw,nw);
    printf("     bt_uint%u_t res;\n",nw);
    printf("     asm (\"\\n\\t\"\n");
    printf("          \"add.cc.u32      %%0, %%%u, %%%u;\\n\\t\"\n",N,DN);
    for (uint32_t i=1;i<N-1;i++) printf("          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,N+i,DN+i);
    printf("          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,DN-1,N+DN-1);
//     printf("          \"}\"\n");
    printf("          : ");
    print_regs('=',"res");
    printf("\n          : ");
    print_regs(' ',"a");
    printf(",\n           ");
    print_regs(' ',"b");
    printf(");\n");
    printf("      return res;\n}\n\n");
}


void gera_two_complement(void){
   printf("__device__ bt_uint%u_t two_complement_uint%u (bt_uint%u_t a) {\n",nw,nw,nw);
   printf("     bt_uint%u_t res;\n",nw);
   printf("     asm (\"\\n\\t\"\n");
   for (uint32_t i=0;i<N;i++) printf("          \"not.b32         %%%u, %%%u;\\n\\t\"\n",i,i+N);
   printf("          \"add.cc.u32      %%0, %%0, 1;\\n\\t\"\n");
   for (uint32_t i=1;i<N-1;i++) printf("          \"addc.cc.u32     %%%u, %%%u, 0;\\n\\t\"\n",i,i);
   printf("          \"addc.u32        %%%u, %%%u, 0;\\n\\t\"\n",N-1,N-1);
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"res");
   printf("\n         : ");
   print_regs(' ',"a");
   printf(");\n");
   printf("      return res;\n}\n\n");
}

void gera_x2mod(void){
   printf("__device__ bt_uint%u_t x2mod_uint%u (bt_uint%u_t a, bt_uint%u_t Ntc) {\n",nw,nw,nw,nw);
   printf("    bt_uint%u_t s,sN;\n",nw);
   printf("    uint32_t c;\n");
   printf("     asm (\"\\n\\t\"\n");
   printf("          \"add.cc.u32      %%0, %%%u, %%%u;\\n\\t\"\n",DN+1,DN+1);
   for (uint32_t i=1;i<N-1;i++) printf("          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,DN+1+i,DN+1+i);
   printf("          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,DN+N,DN+N);
   printf("          \"add.cc.u32      %%%u, %%%u, %%%u;\\n\\t\"\n",N,0,DN+N+1);
   for (uint32_t i=1;i<N;i++) printf("          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",N+i,i,DN+N+1+i);
   printf("          \"addc.u32        %%%u, 0, 0;\\n\\t\"\n",DN);
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"s");
   printf(",\n           ");
   print_regs('=',"sN");
   printf(",\"=r\"(c)\n         : ");
   print_regs(' ',"a");
   printf(",\n           ");
   print_regs(' ',"Ntc");
   printf(");\n");
   printf("   if (c) return sN; else return s;\n");
   printf("}\n\n");
}


void gera_if_ge_add(void){
   printf("__device__ bt_uint%u_t  if_ge_add_uint%u(bt_uint%u_t a, bt_uint%u_t Ntc){\n",nw,nw,nw,nw);
   printf("    uint32_t carry;\n");
   printf("    bt_uint%u_t res;\n",nw);
   printf("     asm (\"\\n\\t\"\n");
   printf("          \"add.cc.u32      %%%u, %%%u, %%%u;\\n\\t\"\n",0,N+1,DN+1);
   for (uint32_t i=1;i<N;i++) printf("          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,N+i+1,DN+1+i);
   printf("          \"addc.u32        %%%u, 0, 0;\\n\\t\"\n",N);
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"res");
   printf(",\"=r\"(carry)\n         : ");
   print_regs(' ',"a");
   printf(",\n           ");
   print_regs(' ',"Ntc");
   printf(");\n");   
   printf("     if (carry) return res; else return a;\n");
   printf("}\n\n");
}


void gera_shiftR(void){
   printf("__device__ bt_uint%u_t shiftR_%u(bt_uint%u_t a) {\n",nw,nw,nw);
   printf("    bt_uint%u_t res;\n",nw);
   printf("     asm (\"\\n\\t\"\n");
   for (uint32_t i=0;i<N-1;i++) printf("          \"shf.r.clamp.b32 %%%u, %%%u, %%%u, 1;\\n\\t\"\n",i,N+i,N+i+1);
   printf("          \"shf.r.clamp.b32 %%%u, %%%u,  0, 1;\\n\\t\"\n",N-1,DN-1);
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"res");
   printf("\n         : ");
   print_regs(' ',"a");
   printf(");\n");   
   printf("    return res;\n");
   printf("}\n\n");    
}

void gera_inv_mod_pow2(void){
   printf("__device__ bt_uint%u_t inv_mod_pow2_%u(bt_uint%u_t x){\n",nw,nw,nw);
   printf("    bt_uint%u_t y,xc=x;\n",nw);
   printf("    uint32_t u=0x40000000; // set MSB and shift right\n");
   printf("    xc=shiftR_%u(xc);\n",nw);
   printf("    for (uint32_t i=1;i<31;i++) {\n");
   printf("        if (xc.b0&1) {\n");  
   printf("          xc=add_uint%u(xc,x);\n",nw);
   printf("          u=u|0x80000000;  //set MSB\n");
   printf("        }\n");
   printf("        xc=shiftR_%u(xc);\n",nw);
   printf("        u=u>>1;\n");    
   printf("    }\n");
   printf("    if (xc.b0&1) {\n");
   printf("       xc=add_uint%u(xc,x);\n",nw);
   printf("       u=u|0x80000000;  //set MSB\n");
   printf("    }\n");
   printf("    y.v[0]=u;\n");
   printf("    for (uint32_t j=1; j<%u;j++) {\n",N);
   printf("        xc=shiftR_%u(xc);\n",nw);
   printf("        u=0;\n");
   printf("        for (uint32_t i=0;i<31;i++) {\n");
   printf("            if (xc.b0&1) {\n");  
   printf("              xc=add_uint%u(x,xc);\n",nw);
   printf("              u=u|0x80000000;  //set MSB\n");
   printf("            }\n");
   printf("            xc=shiftR_%u(xc);\n",nw);
   printf("            u=u>>1;\n");    
   printf("        }\n");
   printf("        if (xc.b0&1) {\n");
   printf("           xc=add_uint%u(x,xc);\n",nw);
   printf("           u=u|0x80000000;  //set MSB\n");
   printf("        }\n");
   printf("        y.v[j]=u;\n");
   printf("    }\n    return y;\n");
   printf("}\n\n");
}



void gera_mulmod(void){
   zera();
   for (uint32_t i=0;i<N;i++)  gera_linha(i); 

   //zera operações entre N e DN
   for (uint32_t i=N;i<DN;i++) 
       for (uint32_t j=0;j<DN_MAX;j++) {
         ops[i][j]=0;
         opi[i][j]=0;
         HL[i][j]=0;
       }  

   //corrige indices registradores entre 0 e N
   for (uint32_t i=0;i<N;i++) 
       for (uint32_t j=0;j<DN_MAX;j++) {
         if (ops[i][j]>0) ops[i][j]-=N;  
         if (opi[i][j]>0) opi[i][j]-=N;  
       }  
       
       
   marca_primeiro_ultimo();
   printf("// multiplication %u bits X %u bits mod 2^%u => %u bits\n",nw,nw,nw,nw,nw);
   mostra_mult(N,0);
   printf("__device__  bt_uint%u_t mulmod_%u_%u(bt_uint%u_t lo, bt_uint%u_t Ninv) {\n",nw,nw,nw,nw,nw);
   printf("    bt_uint%u_t x;\n",nw);
   printf("     // calculate x=lo*Ninv mod 2^%u\n",nw);
   printf("     asm (\"\\n\\t\"\n");
   
   gera_asm_mult(N);
   
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"x");
   printf("\n         : ");
   print_regs(' ',"lo");
   printf(",\n           ");
   print_regs(' ',"Ninv");
   printf(");\n");   

   printf("   return x;\n");
   printf("}\n\n");
}


void gera_addcarry(void){
   printf("__device__  bt_uint%u_t addcarry_uint%u(bt_uint%u_t x, bt_uint%u_t y,  uint32_t carry){\n",nw,nw,nw,nw);
   printf("     asm (\"\\n\\t\"\n");
   printf("          \"add.cc.u32      %%%u, 0xFFFFFFFF, %%%u; \\n\\t\"   // acumulate carry\n",N,N);
   for (uint32_t i=0;i<N-1;i++) printf("          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,i,N+1+i);
   printf("          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,N-1,DN);
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('+',"x");
   printf(",\"+r\"(carry)\n         : ");
   print_regs(' ',"y");
   printf(");\n");   
   printf("   return x;\n");
   printf("}\n\n");
}

void gera_carry(void){
   printf("__device__ uint32_t carry_%u(bt_uint%u_t x, bt_uint%u_t y){\n",nw,nw,nw);
   printf("    uint32_t carry;\n");
   printf("     asm (\"\\n\\t\"\n");
   printf("          \"add.cc.u32      %%0, %%1, %%%u; \\n\\t\"\n",N+1);
   for (uint32_t i=1;i<N;i++) printf("          \"addc.cc.u32     %%0, %%%u, %%%u;\\n\\t\"\n",i+1,N+i+1);
   printf("          \"addc.u32        %%0, 0, 0;\\n\\t\"\n");
//    printf("          \"}\"\n");
   printf("         : \"=r\"(carry)\n");
   printf("         : ");
   print_regs(' ',"x");
   printf(",\n           ");
   print_regs(' ',"y");
   printf(");\n");   
   printf("    return carry;\n");
   printf("}\n\n");   
}

void gera_redc(void){
   printf("__device__  bt_uint%u_t redc_%u(bt_uint%u_t hi, bt_uint%u_t lo, bt_uint%u_t N, bt_uint%u_t Ntc, bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw,nw,nw);
   printf("   bt_uint%u_t x,rhi=hi,rlo=lo;\n",nw);
   printf("   uint32_t carry;\n");   
   printf("   x=mulmod_%u_%u(lo,Ninv);\n",nw,nw);   
   printf("   mul_%u_%u(&rhi,&rlo,x,N);\n",nw,nw<<1);
   printf("     // [x, - ]= [hi,lo]+[rhi,rlo]\n");
   printf("   carry=carry_%u(lo,rlo);\n",nw);
   printf("   x=addcarry_uint%u(hi,rhi,carry);\n",nw);
   printf("   return if_ge_add_uint%u(x,Ntc);\n",nw);
   printf("}\n\n");    
}


void gera_asm_square(void) {
    char op[5];
    uint64_t cmult=0,cadd=0;
    uint8_t status_col[DN],carry;
    for (uint32_t j=0;j<DN;j++) status_col[j]=0;
    printf("    // multiplies distinct operands\n");   
    for (uint32_t i=0;i<DN-1;i++) {
        uint32_t soma=0;
        carry=0;
        for (uint32_t j=0;j<DN;j++) soma+=ops[j][i];
        if (soma==0) continue;
        printf("\n");
        for (uint32_t j=0;j<DN;j++) {
            if (ops[j][i]>0) {                
                if (status_col[j]==0) { // não existe valor anterior na coluna
                    carry=print_operacao_coluna_livre(i,j,DN,status_col,carry,&cadd,&cmult);
                } else {  //coluna tem valor anterior
                    carry=print_operacao_coluna_ocupada(i,j,DN,status_col,carry,&cadd,&cmult);
                }
            }
        }
    }
    printf("\n    // duplicate sum of multiplications of different operands\n");
    
    ins_addcc("%1","%1","%1");
    for (uint32_t j=2;j<DN-1;j++) {
      sprintf(op,"%%%u",j);
      ins_addccc(op,op,op);
    }
    sprintf(op,"%%%u",DN-1);
    if (status_col[DN-1]) ins_addc(op,op,op); else ins_addc(op,"0","0");
    cadd+=DN;
    
    printf("\n    // multiplies equal operands and sum at previous value\n"); 
    carry=print_operacao_coluna_livre(DN-1,0,DN,status_col,0,&cadd,&cmult);
    for (uint32_t j=1;j<DN;j++)
        carry=print_operacao_coluna_ocupada(DN-1,j,DN,status_col,carry,&cadd,&cmult);    
    
    printf("\n             // %lu additions and %lu multiplications\n",cadd,cmult);
}


void gera_square(void){
   zera();
   // produtos distintos
   for (uint32_t i=1;i<N;i++) {
       uint32_t linha=2*i+1; 
       for (uint32_t j=0;j<i;j++) {
           uint32_t pos=i+j;        
           uint32_t lindest=linha_vazia(pos,linha);
           ops[pos][lindest]=DN+j+1;
           opi[pos][lindest]=DN+i+1;
           ops[pos+1][lindest]=DN+j+1;
           opi[pos+1][lindest]=DN+i+1;
           HL[pos+1][lindest]=1;     
       }
   }
   inverte_mult();
   // quadrados na última linha
   for (uint32_t j=0;j<N;j++) {
       ops[j<<1][DN-1]=DN+j+1;
       opi[j<<1][DN-1]=DN+j+1;
       ops[(j<<1)+1][DN-1]=DN+j+1;
       opi[(j<<1)+1][DN-1]=DN+j+1;
       HL[(j<<1)+1][DN-1]=1;     
   }
   marca_primeiro_ultimo();    
   printf("// square %u bits mod 2^%u => %u bits\n",nw,nw,nw);
   mostra_mult(DN,1);
   
   printf("__device__ bt_uint%u_t square_%u(bt_uint%u_t y, bt_uint%u_t N, bt_uint%u_t Ntc, bt_uint%u_t Ninv) {\n",nw,nw,nw,nw,nw,nw);
   printf("    bt_uint%u_t hi,lo;\n",nw);
   printf("    // calculate y^2\n");
   printf("     asm (\"\\n\\t\"\n");
   gera_asm_square();   
//    printf("          \"}\"\n");
   printf("         : ");
   print_regs('=',"lo");
   printf(",\n           ");
   print_regs('=',"hi");
   printf("\n         : ");
   print_regs(' ',"y");
   printf(");\n");   

   printf("   return redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("}\n\n");
    
}

void gera_power(void){
   printf("__device__ bt_uint%u_t power_%u(uint32_t a, uint32_t M,bt_uint%u_t N,bt_uint%u_t Ntc, bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
   printf("    bt_uint%u_t y={a",nw);
   for (uint32_t i=1;i<N;i++) printf(",0");
   printf("};\n");
   printf("    for (uint32_t j=0;j<%u;j++)  {  //calcule y=a*2^%u mod N\n",nw,nw);
   printf("        y=x2mod_uint%u(y,Ntc);\n",nw);
   printf("    }\n");
   printf("    for (uint32_t j=0;j<=M;j++)  {\n");
   printf("        y=square_%u(y,N,Ntc,Ninv);\n",nw);
   printf("    }\n");
   printf("    return y;\n");
   printf("}\n\n");
}


void gera_calculate_power_prime(void){
   printf("__device__ void calculate_power_prime_%u(bt_uint%u_t *abp, uint32_t M, bt_uint%u_t N,bt_uint%u_t Ntc,bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
   printf("     // prime powers in Montogomery Form\n");
   printf("     abp[0]=power_%u(2,M,N,Ntc,Ninv);\n",nw);
   printf("     abp[1]=power_%u(3,M,N,Ntc,Ninv);\n",nw);
   printf("     abp[3]=power_%u(5,M,N,Ntc,Ninv);\n",nw);
   printf("     abp[5]=power_%u(7,M,N,Ntc,Ninv);\n",nw);
   printf("     abp[9]=power_%u(11,M,N,Ntc,Ninv);\n",nw);
   printf("}\n\n");    
}

void gera_calculate_power_composite(void){
   printf("__device__ void calculate_power_composite_%u(bt_uint%u_t *abp, uint32_t M, bt_uint%u_t N,bt_uint%u_t Ntc,bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
   printf("        bt_uint%u_t hi,lo;\n",nw);  
   printf("        // another powers in Montogomery Form\n");
   printf("        mul_%u_%u(&hi,&lo,abp[0],abp[1]);\n",nw,nw<<1);
   printf("        abp[4]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);

   printf("        mul_%u_%u(&hi,&lo,abp[0],abp[2]);\n",nw,nw<<1);
   printf("        abp[6]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);

   printf("        mul_%u_%u(&hi,&lo,abp[0],abp[3]);\n",nw,nw<<1);
   printf("        abp[8]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);

   printf("        mul_%u_%u(&hi,&lo,abp[1],abp[2]);\n",nw,nw<<1);
   printf("        abp[10]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("}\n\n");
}



void gera_verify(void) {
   printf("__device__ uint8_t verify_%u(bt_uint%u_t *abp, bt_uint%u_t Ntc){\n",nw,nw,nw);
   printf("    bt_uint%u_t one={1",nw);
   for (uint32_t i=1;i<N;i++) printf(",0");
   printf("};\n");
   printf("    for (uint32_t j=0;j<%u;j++)  {  //calcule y=2^%u mod N\n",nw,nw);
   printf("       one=x2mod_uint%u(one,Ntc);\n",nw);
   printf("    }\n");            
   printf("    uint8_t res=0;\n");        
   printf("    for (uint8_t j=0;j<NUM_AB;j++) {\n");    
   printf("        bt_uint%u_t ap=abp[av[j]-2],bp;\n",nw);    
   printf("        if (bv[j]==1) bp=one; else bp=abp[bv[j]-2];\n");    
   printf("        res+=((ap.b0==bp.b0)");    
   for (uint32_t i=1;i<N;i++) printf("&&(ap.b%u==bp.b%u)",i,i);    
   printf(");\n");    
   printf("    }\n");            
   printf("    return res;\n");    
   printf("}\n\n");    
}


void gera_xGF(void) {
   printf("__global__ void xGF_%u(uint32_t M){\n",nw);
   printf("    uint32_t ind=threadIdx.x; //candidate index\n");
   printf("    uint32_t indBloc=blockIdx.x; //block index\n");
   printf("    if (ind<numCand[indBloc]) {\n");
   printf("        bt_uint%u_t abpower[11];// 2 to 12 power array\n",nw);
   printf("        bt_uint%u_t N,Ntc,Ninv;\n",nw);        
   printf("        N=cand_%u[indBloc][ind];\n",nw);
   printf("        Ntc=two_complement_uint%u(N);\n",nw);
   printf("        // calculate -(N^-1 mod 2^s)\n");
   printf("        Ninv=two_complement_uint%u(inv_mod_pow2_%u(N));\n",nw,nw);
   printf("        calculate_power_prime_%u(abpower,M,N,Ntc,Ninv);\n",nw);   
   printf("        abpower[2]=square_%u(abpower[0],N,Ntc,Ninv);\n",nw);
   printf("        abpower[7]=square_%u(abpower[1],N,Ntc,Ninv);\n",nw);        
   printf("        calculate_power_composite_%u(abpower,M,N,Ntc,Ninv);\n",nw);        
   printf("        if (verify_%u(abpower,Ntc)) {\n",nw);
   printf("           uint32_t pos=atomicAdd(&numChecked,1);\n");
   printf("           checkCand_%u[pos]=N;\n",nw);
   printf("        }\n");   
   printf("    }\n");    
   printf("}\n\n");   
}

void gera_fill_cand(void){
   printf("__global__ void fill_cand_%u(uint32_t n){\n",nw);
   printf("    unsigned char *tab=d_tab_data[n];\n");
   printf("    uint32_t indBloc=blockIdx.x; //índice bloco Cand\n");
   printf("    uint64_t k0,k1,i,dK,nc,kindB;\n"); 
   printf("    uint64_t kmax=kCurrent+kStep;\n"); 
   printf("    uint64_t sizeBlock=(kStep+NUM_BLOCK_CAND-1)/NUM_BLOCK_CAND;\n");
   printf("    k0=kCurrent+(indBloc*sizeBlock);\n");
   printf("    if ((k0&1)==0) k0++;\n");
   printf("    k1=k0+sizeBlock;\n");
   printf("    if (k1>kmax) k1=kmax;\n");    
   printf("    kindB=kind[indBloc];\n");
   printf("    if (kindB<k0) kindB=k0;\n");
   printf("    i=(kindB-kCurrent)>>1;  // position in bitmap\n");
   printf("    dK=(k1-kCurrent)>>1;            /// max position im bitmap\n");
   printf("    nc=0;\n");    
   printf("    while (i<dK) {\n");
   printf("        if (tab[i>>3]&((uint8_t)(1<<(i&7))))  { //is candidate\n");
   printf("          cand_%u[indBloc][nc]=kn_bt%u(kindB,n+nCurrent);\n",nw,nw);  
   printf("          nc++;\n");
   printf("          if (nc==SIZE_BLOCK_CAND) {\n");
   printf("              kindB+=2;\n");
   printf("              numCand[indBloc]=nc; \n");
   printf("              break; \n");
   printf("          }  \n");
   printf("        } \n");
   printf("        i++; \n");
   printf("        kindB+=2; \n");
   printf("    }  \n");
   printf("    numCand[indBloc]=nc;\n");
   printf("    kind[indBloc]=kindB; \n");
   printf("}\n\n");       
}

void gera_uinttompz(void){
   printf("void uint%utompz(mpz_t x,bt_uint%u_t v){\n",nw,nw);
   printf("   //bt_uint%u_t to mpz\n",nw);
   printf("   mpz_set_ui(x,v.b%u);\n",N-1);
   for (uint32_t j=N-1;j>0;j--) {
      printf("   mpz_mul_2exp(x,x,32);\n");
      printf("   mpz_add_ui(x,x,v.b%u);\n",j-1);  
   }
   printf("}\n\n");
}

void gera_check(void){
   printf("void check_%u(bt_uint%u_t x, uint32_t M) {\n",nw,nw);
   printf("   mpz_t k,a,km;\n");
   printf("   mpz_inits(a,km,k,0);\n");
   printf("   uint%utompz(k,x);\n",nw);
   printf("   // is 13-PRP ?\n");
   printf("   mpz_set_ui(a,13);\n");
   printf("   mpz_sub_ui(km,k,1);\n");
   printf("   mpz_powm(a,a,km,k);\n");
   printf("   if (mpz_cmp_ui(a,1)==0) { // if is 13-PRP\n");
   printf("        mpz_fdiv_q_2exp(k,k,M);\n");
   printf("        test_xGF_power_gmp(k, M);\n");
   printf("   }\n");
   printf("   mpz_clears(a,km,k,0);\n}\n\n");
}


void gera_head_tst(void){
   printf("__device__ __managed__ bt_uint%u_t res, rN, rNinv,ry,ab[11];\n\n",nw);
}

void gera_tst(void){
   printf("__global__ void tst(void){\n");
   printf("    bt_uint%u_t N,Ntc, Ninv,z;\n",nw);
   printf("    z.b0=0; z.b1=0; z.b2=0;z.b3=0;\n");
   printf("    N.b3=0x678; N.b2=0xce69b000; N.b1=0; N.b0=1;\n");
   printf("//     N.b0=123456791; N.b1=32142; N.b2=3241;N.b3=5647;\n");
   printf("    rN=N;\n");
   printf("    Ntc=two_complement_uint%u(N);\n",nw);
   printf("    Ninv=two_complement_uint%u(inv_mod_pow2_%u(N));\n",nw,nw); 
   printf("    rNinv=Ninv;\n");
   printf("    ab[0]=power_%u(2,75,N,Ntc,Ninv);\n",nw);
   printf("    ab[1]=power_%u(3,75,N,Ntc,Ninv);\n",nw);
   printf("    ab[3]=power_%u(5,75,N,Ntc,Ninv);\n",nw);
   printf("    ab[5]=power_%u(7,75,N,Ntc,Ninv);\n",nw);
   printf("    ab[9]=power_%u(11,75,N,Ntc,Ninv);\n",nw);
   printf("    ab[7]=square_%u(ab[1],N,Ntc,Ninv);\n",nw);
   printf("    ab[2]=square_%u(ab[0],N,Ntc,Ninv);\n",nw);
   printf("\n");
   printf("        {\n");
   printf("          bt_uint%u_t hi,lo;\n",nw);
   printf("          mul_%u_%u(&hi,&lo,ab[0],ab[1]);\n",nw,nw<<1);
   printf("          ab[4]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("\n");
   printf("          mul_%u_%u(&hi,&lo,ab[0],ab[2]);\n",nw,nw<<1);
   printf("          ab[6]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("\n");
   printf("          mul_%u_%u(&hi,&lo,ab[0],ab[3]);\n",nw,nw<<1);
   printf("          ab[8]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("\n");
   printf("          mul_%u_%u(&hi,&lo,ab[1],ab[2]);\n",nw,nw<<1);
   printf("          ab[10]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
   printf("        }\n");
   printf("\n");    
   printf("//     for (uint32_t j=0;j<11; j++) \n");
   printf("//       ab[j]=redc_%u(z,ab[j],N,Ntc,Ninv);\n",nw);
   printf("\n");    
   printf("    res=power_%u(9,75,N,Ntc,Ninv);\n",nw);
   printf("\n");    
   printf("}\n");
   printf("\n");
   printf("void teste_Mont_%u(void){\n",nw);
   printf("    mpz_t aux;\n");
   printf("    mpz_init(aux);\n");
   printf("   tst<<<1,1>>>();\n");
   printf("   cudaDeviceSynchronize();\n");
   printf("   uint%utompz(aux,rN);\n",nw);
   printf("   gmp_printf(\"N= %%Zd\\n\",aux);\n");
   printf("   uint%utompz(aux,rNinv);\n",nw);
   printf("   gmp_printf(\"Ninv= %%Zd\\n\",aux);\n");
   printf("   uint%utompz(aux,ry);\n",nw);
   printf("   gmp_printf(\"y= %%Zd\\n\",aux);\n");
   printf("   uint%utompz(aux,res);\n",nw);
   printf("   gmp_printf(\"res= %%Zd\\n\",aux);\n");
   printf("   for (uint32_t j=0;j<11; j++) {\n");
   printf("     uint%utompz(aux,ab[j]);\n",nw);
   printf("     gmp_printf(\"pot %%u = %%Zd\\n\",j+2,aux);\n");
   printf("   }\n");
   printf("\n");
   printf("\n");   
   printf("   mpz_clear(aux);\n");
   printf("   exit(1);\n");
   printf("}\n\n");
    
}


int main(int argc, char *argv[]){
   if (argc!=2) {
      fprintf(stderr,"Use %s nw\n",argv[0]);
      exit(1); 
   }
   nw=atoll(argv[1]);
   N=(nw>>5);  // número de palavras
   DN=(N<<1);  // dobro de N
   printf("\n");
   gera_tipo_base_cabecalho();
//    if (nw==192) gera_head_tst();
   gera_kn_bt();
   gera_add_uint();
   gera_two_complement();
   gera_x2mod();
   gera_if_ge_add();
   gera_shiftR();
   gera_inv_mod_pow2();
   gera_mult();
   gera_mulmod();
   gera_addcarry();
   gera_carry();
   gera_redc();
   gera_square();
   gera_power();
   gera_calculate_power_prime();
   gera_calculate_power_composite();
   gera_verify(); 
   gera_xGF();
   gera_fill_cand();  
   gera_uinttompz();
//    gera_check(); 
//    if (nw==192) gera_tst();
   return 0; 
}
