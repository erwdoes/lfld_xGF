#define CCMAJOR 6
#define CCMINOR 1
#include "bt64bits.cu"
#include "bt96bits.cu"
#include "bt128bits.cu"
#include "bt160bits.cu"
#include "bt192bits.cu"
#include "bt224bits.cu"
#include "bt256bits.cu"
#include "bt288bits.cu"
#include "bt320bits.cu"
#include "bt352bits.cu"
#include "bt384bits.cu"
#include "bt416bits.cu"
