uint32_t bits_size(uint64_t k, uint32_t M){
    uint32_t bits=M;
    if ((k&0xFFFFFFFF00000000UL)!=0) {bits+=32; k=(k>>32);}
    if ((k&0xFFFF0000UL)!=0) {bits+=16; k=(k>>16);}
    if ((k&0xFF00UL)!=0) {bits+=8; k=(k>>8);}
    if ((k&0xF0UL)!=0) {bits+=4; k=(k>>4);}
    if ((k&0xCUL)!=0) {bits+=2; k=(k>>2);}
    if ((k&0x2UL)!=0) {bits++; k=(k>>1);}
    if ((k&0x1UL)!=0) bits++;
    return bits;
}

uint64_t choose_pmax(uint64_t kmax,uint32_t nmax){
    uint64_t max;
    uint32_t bs=bits_size(kmax,nmax);
    if (bs<=64) max=200;
    else if (bs<=96) max=4000;
    else if (bs<=128) max=2000000;
    else if (bs<=160) max=30000000;
    else if (bs<=192) max=40000000;
    else if (bs<=224) max=80000000;    
    else if (bs<=256) max=90000000;    
    else if (bs<=288) max=100000000;    
    else if (bs<=320) max=140000000;    
    else if (bs<=352) max=150000000;    
    else if (bs<=384) max=170000000;
    else if (bs<=416) max=190000000;
    else max=200000000;
    return max;
}   
