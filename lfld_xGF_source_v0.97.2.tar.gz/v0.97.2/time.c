#include "time.h"
#include <stdio.h>
#include <stdlib.h>

double getTime(void){
     struct timeval  tv;
     gettimeofday(&tv, NULL);
     return (((double) tv.tv_usec) / 1000000 + (double) tv.tv_sec );
}


void showTime(FILE *f){
    char months[12][5]={"Jan","Feb","Mar","Apr","May","June","July","Aug","Sept","Oct","Nov","Dec"};
    struct tm d;
    time_t sec;
 
    time(&sec);   
    localtime_r(&sec,&d);  
    fprintf(f,"[%d %s %d %d:%.2d:%.2d] ",1900+d.tm_year, months[d.tm_mon],d.tm_mday,d.tm_hour,d.tm_min,d.tm_sec);
}
