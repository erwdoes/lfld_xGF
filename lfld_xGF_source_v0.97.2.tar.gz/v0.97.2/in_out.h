#ifndef IN_OUT_H
#define IN_OUT_H
void writeFactor(mpz_t k,uint64_t a,uint64_t b,uint64_t m,uint64_t ind, uint32_t prime_prp);
void write_ini(const char *name,uint64_t k, uint32_t n);
void write_status(uint64_t k, uint32_t n);
void read_ini(const char *name);
void save_sieve_prime_table(void);
void save_candidates(void);
void save_head_ABC_file(const char *name);
#endif
