#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "kernel.h"

#define N_MAX  100
#define DN_MAX N_MAX<<1

uint32_t ops[DN_MAX][DN_MAX];  //operando superior
uint32_t opi[DN_MAX][DN_MAX];  //operando inferior
uint8_t HL[DN_MAX][DN_MAX];  // 1=high  0=low
//uint32_t DN,N,nw;


void zera(void){
    uint32_t i,j;
    for (i=0;i<DN_MAX;i++) 
        for (j=0;j<DN_MAX;j++) {
            ops[i][j]=0;
            opi[i][j]=0;
            HL[i][j]=0;
        }
}


uint32_t linha_vazia(uint32_t pos, uint32_t max){
    uint32_t lin;
    lin=0; 
    while ((lin<=max)&& ((ops[pos][lin]+ops[pos+1][lin])!=0)) lin++;
    return lin;
}


void gera_linha(uint32_t nw, uint32_t ni){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N
    uint32_t linha=2*ni+1; 
    for (uint32_t j=0;j<N;j++) {
        uint32_t pos=ni+j;        
        uint32_t lindest=linha_vazia(pos,linha);
        ops[pos][lindest]=DN+N+j+1;
        opi[pos][lindest]=DN+ni+1;
        ops[pos+1][lindest]=DN+N+j+1;
        opi[pos+1][lindest]=DN+ni+1;
        HL[pos+1][lindest]=1;     
    }
}

void marca_primeiro_ultimo(uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N
    for (uint32_t i=0;i<DN;i++) {
        uint32_t j=0;
        while ((j<DN)&&(ops[j][i]==0)) j++;
        if (j<DN) HL[j][i]|=2; // marca como primeiro
        j=N<<1;
        while ((j>0)&&(ops[j-1][i]==0)) j--;
        if (j>0) HL[j-1][i]|=4; // marca como ultimo
    }
    for (uint32_t j=0;j<DN;j++) {      
        if (ops[j][0]!=0) HL[j][0]|=8; // marca como primeiro da coluna na primeira linha
        uint32_t i=0;
        while ((i<DN) && (ops[j][i]==0)) i++;
        if ((i<DN)&&((HL[j][i]&1)==0)) HL[j][i]|=8; // marca como primeiro da coluna apenas L
        
    }
}

void mostra_mult(FILE *f, uint32_t nw, uint32_t Lim, uint8_t square) {   
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N
    fprintf(f,"// registers map\n\n");
    fprintf(f,"//        |");
    if (square) for(uint32_t j=0;j<N;j++) fprintf(f,"  %3u  |",Lim+N-j-1);  
    else for(uint32_t j=0;j<N;j++) fprintf(f,"  %3u  |",Lim+DN-j-1);     
    fprintf(f,"\n");
    fprintf(f,"//      X |");
    for(uint32_t j=0;j<N;j++) fprintf(f,"  %3u  |",Lim+N-j-1);     
    fprintf(f,"\n\n");
    fprintf(f,"// |");
    for (uint32_t j=0;j<Lim;j++) fprintf(f,"      %3u        |",Lim-j-1);
    fprintf(f,"\n// |");
    for (uint32_t j=0;j<Lim;j++) fprintf(f,"=================|");
    fprintf(f,"\n");
    for (uint32_t i=0;i<DN;i++) {
        uint32_t soma=0;        
        for (uint32_t j=0;j<Lim;j++) soma+=ops[j][i];
        if (soma>0) {
            fprintf(f,"// | ");
            for (uint32_t j=Lim;j>=1;j--) {
                if (ops[j-1][i]>0) {
                    fprintf(f,"(%3u,%3u).",ops[j-1][i]-1,opi[j-1][i]-1);
                    if (HL[j-1][i]&1) fprintf(f,"H [%X] | ",HL[j-1][i]); else fprintf(f,"L [%X] | ",HL[j-1][i]);
                } else fprintf(f,"                | ");
            }
            fprintf(f,"\n");
        }
    }
    fprintf(f,"\n");
}

void ins_asm(FILE *f) {
    fprintf(f,"     asm(\"\\n\\t\"\n");
}

void ins_mulhi(FILE *f, char *dest,char *op1, char *op2){
    fprintf(f,"         \"mul.hi.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_mullo(FILE *f, char *dest,char *op1, char *op2){
    fprintf(f,"         \"mul.lo.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_madchi(FILE *f,char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"madc.hi.u32    %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madhi(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"mad.hi.u32     %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madclo(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"madc.lo.u32    %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madlo(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"mad.lo.u32     %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}


void ins_madchicc(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"madc.hi.cc.u32 %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madclocc(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"madc.lo.cc.u32 %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madhicc(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"mad.hi.cc.u32  %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_madlocc(FILE *f, char *dest,char *op1, char *op2, char *op3){
    fprintf(f,"         \"mad.lo.cc.u32  %5s, %5s, %5s, %5s; \\n\\t\"\n",dest,op1,op2,op3);
}

void ins_addc(FILE *f, char *dest,char *op1, char *op2){
    fprintf(f,"         \"addc.u32       %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_addccc(FILE *f, char *dest,char *op1, char *op2){
    fprintf(f,"         \"addc.cc.u32    %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}

void ins_addcc(FILE *f, char *dest,char *op1, char *op2){
    fprintf(f,"         \"add.cc.u32     %5s, %5s, %5s;        \\n\\t\"\n",dest,op1,op2);
}


void ins_registers_mult(FILE *f, uint32_t nw) {
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"\n         : ");
    for (uint32_t i=0;i<N;i++) fprintf(f," \"=r\" (lo->b%u),",i);
    fprintf(f,"\n          ");
    for (uint32_t i=0;i<N-1;i++) fprintf(f," \"=r\" (hi->b%u),",i);
    fprintf(f," \"=r\" (hi->b%u)\n         : ",N-1);
    for (uint32_t i=0;i<N;i++) fprintf(f," \"r\" (x.b%u),",i);
    fprintf(f,"\n          ");
    for (uint32_t i=0;i<N-1;i++) fprintf(f," \"r\" (y.b%u),",i);
    fprintf(f," \"r\" (y.b%u));\n",N-1);
}



uint32_t print_operacao_coluna_ocupada(FILE *f, uint32_t i, uint32_t j, uint32_t Limite, uint8_t *status_col,uint32_t carry,uint64_t *cadd, uint64_t *cmult) {
    char opdest[5],opdestp[5],op1[5],op2[5];
    sprintf(opdest,"%%%u",j);
    sprintf(opdestp,"%%%u",j+1);
    sprintf(op1,"%%%u",ops[j][i]-1);
    sprintf(op2,"%%%u",opi[j][i]-1);
    if (carry) { //com carry 
        if (HL[j][i]&4) { // último da linha            
            if (j==Limite-1) {
                if (HL[j][i]&1) ins_madchi(f,opdest,op1,op2,opdest); else ins_madclo(f,opdest,op1,op2,opdest);
            } else if (j==Limite-2) {
                if (HL[j][i]&1) ins_madchicc(f,opdest,op1,op2,opdest); else  ins_madclocc(f,opdest,op1,op2,opdest);
                if (status_col[j+1]==0) ins_addc(f,opdestp,"0","0"); else ins_addc(f,opdestp,opdestp,"0");
                (*cadd)++;
                status_col[j+1]|=2; //ocupado com adição
            } else {
                if (HL[j][i]&1) ins_madchicc(f,opdest,op1,op2,opdest); else ins_madclocc(f,opdest,op1,op2,opdest);
                uint32_t k=j+1;
                while ((k<Limite-1) && (status_col[k]==1) && (status_col[k+1])==1) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addccc(f,opdestp,opdestp,"0");
                    (*cadd)++;
                    k++;
                }
                if (status_col[k]==1) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addc(f,opdestp,opdestp,"0");
                    (*cadd)++;
                    if (k<Limite-1) {
                        sprintf(opdestp,"%%%u",k+1);
                        ins_addc(f,opdestp,"0","0"); 
                        status_col[k+1]|=2;
                        (*cadd)++;
                    }
                } else {
                    sprintf(opdestp,"%%%u",k);
                    if (status_col[k]==2) ins_addc(f,opdestp,opdestp,"0"); else ins_addc(f,opdestp,"0","0");
                    status_col[k]|=2;
                    (*cadd)++;
                }
            }
        } else { // não é o último da linha
            if (HL[j][i]&1) ins_madchicc(f,opdest,op1,op2,opdest); else  ins_madclocc(f,opdest,op1,op2,opdest); 
        }
        (*cmult)++;
    } else { //sem carry
        if (HL[j][i]&4) { // último da linha
            
            if (j==Limite-1) {
                if (HL[j][i]&1) ins_madhi(f,opdest,op1,op2,opdest); else ins_madlo(f,opdest,op1,op2,opdest);
            } else if (j==Limite-2) {
                if (HL[j][i]&1) ins_madhicc(f,opdest,op1,op2,opdest); else  ins_madlocc(f,opdest,op1,op2,opdest);
                if (status_col[j+1]==0) ins_addc(f,opdestp,"0","0"); else ins_addc(f,opdestp,opdestp,"0");
                (*cadd)++;
                status_col[j+1]++;                 
            } else {
                if (HL[j][i]&1) ins_madhicc(f,opdest,op1,op2,opdest); else ins_madlocc(f,opdest,op1,op2,opdest);
                uint32_t k=j+1;
                while ((k<Limite-1) && (status_col[k]==1) && (status_col[k+1]==1)) {
                    sprintf(opdestp,"%%%u",k);
                    ins_addccc(f,opdestp,opdestp,"0");
                    (*cadd)++;
                    k++;
                }
                sprintf(opdestp,"%%%u",k);
                ins_addc(f,opdestp,opdestp,"0");
                (*cadd)++;
                if (k<Limite-1) {
                    sprintf(opdestp,"%%%u",k+1);
                    ins_addc(f,opdestp,"0","0"); 
                    (*cadd)++;
                    status_col[k]|=2;
                }
            }
        } else {// não é o último da linha
            if (HL[j][i]&1) ins_madhicc(f,opdest,op1,op2,opdest); else  ins_madlocc(f,opdest,op1,op2,opdest);
            carry=1;
        }
        (*cmult)++;
    }    
    return carry;    
}

uint32_t print_operacao_coluna_livre(FILE *f, uint32_t i, uint32_t j, uint32_t Limite, uint8_t *status_col,uint32_t carry,uint64_t *cadd, uint64_t *cmult) {
    char opdest[5],opdestp[5],op1[5],op2[5];
    sprintf(opdest,"%%%u",j);
    sprintf(opdestp,"%%%u",j+1);
    sprintf(op1,"%%%u",ops[j][i]-1);
    sprintf(op2,"%%%u",opi[j][i]-1);
    if (carry) {
        if (HL[j][i]&4) { // último da linha
            if (HL[j][i]&1) ins_madchicc(f,opdest,op1,op2,"0"); else ins_madclocc(f,opdest,op1,op2,"0"); 
            carry=0;
            if (j<Limite-1) {
                if (status_col[j+1]==0) ins_addc(f,opdestp,"0","0"); else ins_addc(f,opdestp,opdestp,"0");
                (*cadd)++;
                status_col[j+1]|=2;
            }
        } else {
            if (HL[j][i]&1) ins_madchicc(f,opdest,op1,op2,"0"); else ins_madclocc(f,opdest,op1,op2,"0"); 
        }
    } else {
        if (HL[j][i]&1) ins_mulhi(f,opdest,op1,op2); else ins_mullo(f,opdest,op1,op2);
    }
    status_col[j]|=1;
    (*cmult)++;
    return carry;
}

void gera_asm_mult(FILE *f, uint32_t nw,uint32_t Limite) {
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    uint64_t cmult=0,cadd=0;
    uint8_t status_col[DN];
    for (uint32_t j=0;j<DN;j++) status_col[j]=0;
    for (uint32_t i=0;i<DN;i++) {
        uint32_t soma=0;
        uint8_t carry=0;
        for (uint32_t j=0;j<Limite;j++) soma+=ops[j][i];
        if (soma==0) continue;
        fprintf(f,"\n");
        for (uint32_t j=0;j<Limite;j++) {
            if (ops[j][i]>0) {                
                if (status_col[j]==0) { // não existe valor anterior na coluna
                    carry=print_operacao_coluna_livre(f,i,j,Limite,status_col,carry,&cadd,&cmult);
                } else {  //coluna tem valor anterior
                    carry=print_operacao_coluna_ocupada(f,i,j,Limite,status_col,carry,&cadd,&cmult);
                }
            }
        }
    }
    fprintf(f,"\n             // %lu additions and %lu multiplications\n",cadd,cmult);
}

void inverte_mult(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    for (uint32_t i=0;i<N-1;i++) {
        for (uint32_t j=0;j<DN;j++) {
            uint32_t aux;
            
            aux=ops[j][i];
            ops[j][i]=ops[j][DN-i-2];
            ops[j][DN-i-2]=aux;
            
            aux=opi[j][i];
            opi[j][i]=opi[j][DN-i-2];
            opi[j][DN-i-2]=aux;
            
            aux=HL[j][i];
            HL[j][i]=HL[j][DN-i-2];
            HL[j][DN-i-2]=(uint8_t)aux;
        }
        
    }
}


void gera_mult(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    zera();
    for (uint32_t i=0;i<N;i++)  gera_linha(nw,i);
    inverte_mult(f,nw);
    fprintf(f,"// multiplication %u bits X %u bits => %u bits\n",nw,nw,nw<<1);
    mostra_mult(f,nw,DN,0);   
    marca_primeiro_ultimo(nw);
    fprintf(f,"__device__ void mul_%u_%u(bt_uint%u_t *hi, bt_uint%u_t *lo,bt_uint%u_t x, bt_uint%u_t y){\n",nw,nw<<1,nw,nw,nw,nw);
    ins_asm(f);
    gera_asm_mult(f,nw,DN);
    ins_registers_mult(f,nw);
    fprintf(f,"}\n\n"); //fim  da função
}


void create_init_function(FILE *f, uint32_t nw) {
//     uint32_t B;
//     B=(nw>>3);  // number bytes per candidate
    
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"//   %u-bit init function \n",nw);
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n\n");    
    
    
    fprintf(f,"__global__ void init%u(void){ // Starts %u bits structures\n",nw,nw);  
    fprintf(f,"    uint32_t BlockBytes;\n");
    fprintf(f,"    uint8_t *pos=buffer_CAND;\n");
    fprintf(f,"    SizeBlockCand_%u=MAX_SIZE_BUFFER_CAND/NUM_BLOCK_CAND/sizeof(bt_uint%u_t); //Number of candidates per block\n",nw,nw);
    fprintf(f,"    SizeBlockCand_%u=((SizeBlockCand_%u>>1)<<1); //ensures being a multiple of 2\n",nw,nw);    
    fprintf(f,"    if (SizeBlockCand_%u>%u) SizeBlockCand_%u=%u; //ensures no more than %u threads\n",nw,threads_Block_Cand(nw),nw,threads_Block_Cand(nw),threads_Block_Cand(nw));
    fprintf(f,"    BlockBytes=sizeof(bt_uint%u_t)*SizeBlockCand_%u; //Block Size in Bytes\n",nw,nw);
    fprintf(f,"    cand_%u[0]=(bt_uint%u_t *) pos;\n",nw,nw);
    fprintf(f,"    for (uint32_t i=1;i<NUM_BLOCK_CAND;i++){ //Calculates the beginning of each block\n");
    fprintf(f,"        pos=pos+BlockBytes;\n");   
    fprintf(f,"        cand_%u[i]=(bt_uint%u_t *) pos;\n",nw,nw);
    fprintf(f,"    }\n");       
    fprintf(f,"}\n\n");
    
}


void gera_tipo_base_cabecalho(FILE *f, uint32_t nw) {
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"typedef union  __align__(%u) {//basic type %u bits\n",SIZE_ALIGN,nw);
    fprintf(f,"     uint32_t v[%u];\n",N);   
    fprintf(f,"     struct {uint32_t ");
    for (uint32_t i=0;i<N-1;i++) fprintf(f,"b%u,",i);
    fprintf(f,"b%u;};\n",N-1);
    fprintf(f,"} bt_uint%u_t;\n\n",nw);
    
    fprintf(f,"__device__ bt_uint%u_t *cand_%u[NUM_BLOCK_CAND]; //array candidates %u bits on device\n\n",nw,nw,nw);
    
    fprintf(f,"__device__ __managed__ uint32_t SizeBlockCand_%u;\n",nw);
    fprintf(f,"__device__ __managed__ bt_uint%u_t checkCand_%u[MAX_CHECKED]; //array marked candidates %u bits on device\n\n",nw,nw,nw);
    
    create_init_function(f, nw);
    
    
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"//   %u-bit arithmetic device codes \n",nw);
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    fprintf(f,"/////////////////////////////////////////////////////////////////////////////////////////////////////\n\n");    
}


void print_regs(FILE *f, uint32_t nw,char tipo,char *ident){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    if (tipo==' ') {  
        for (uint32_t i=0;i<N-1;i++) fprintf(f,"\"r\"(%s.b%u), ",ident,i);
        fprintf(f,"\"r\"(%s.b%u)",ident,N-1);    
    } else {
        for (uint32_t i=0;i<N-1;i++) fprintf(f,"\"%cr\"(%s.b%u), ",tipo,ident,i);
        fprintf(f,"\"%cr\"(%s.b%u)",tipo,ident,N-1);    
    }
}

void gera_kn_bt(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ bt_uint%u_t kn_bt%u(uint64_t k,uint32_t m) {\n",nw,nw);
    fprintf(f,"     bt_uint%u_t res={",nw); 
    for (uint32_t i=1;i<N;i++) fprintf(f,"0,");
    fprintf(f,"0};\n");
    fprintf(f,"     uint32_t w=(m>>5);  // w=m/32\n");
    fprintf(f,"     if (w<%u) {\n",N-1);
    fprintf(f,"         res.v[w]=(uint32_t)(k&0xFFFFFFFF);\n");          
    fprintf(f,"         res.v[w+1]=(uint32_t)(k>>32);\n");
    fprintf(f,"     } else {\n");
    fprintf(f,"         res.b%u=(uint32_t)(k&0xFFFFFFFF);\n",N-1);
    fprintf(f,"     }\n");
    fprintf(f,"     m=m-(w<<5);\n");
    fprintf(f,"     asm (\"\\n\\t\"\n");
    for (uint32_t i=N-1;i>0;i--)  fprintf(f,"          \"shf.l.clamp.b32 %%%u, %%%u, %%%u, %%%u;\\n\\t\"\n",i,i-1,i,N);    
    fprintf(f,"          \"shl.b32 %%0, %%0, %%%u;\\n\\t\"\n",N);     
    fprintf(f,"          \"add.u32 %%0, %%0, 1;\\n\\t\"\n");    
    //     fprintf(f,"          \"}\"\n");
    fprintf(f,"          : ");
    print_regs(f,nw,'+',"res");
    fprintf(f,"\n          : \"r\"(m));\n");    
    fprintf(f,"      return res;\n}\n\n");
}

void gera_bt_kn(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__  uint64_t  bt%u_kn(bt_uint%u_t N,uint32_t m) {\n",nw,nw);
    fprintf(f,"     uint32_t a0,a1,a2;\n");
    if (N==2) { // 64 bits
      fprintf(f,"     a0=N.v[0];\n");    
      fprintf(f,"     a1=N.v[1];\n");    
      fprintf(f,"     a2=0;\n");    
    } else if (N==3) { //96 bits
      fprintf(f,"     a0=N.v[0];\n");    
      fprintf(f,"     a1=N.v[1];\n");    
      fprintf(f,"     a2=N.v[2];\n");    
    } else {     // > 96 bits
       fprintf(f,"     uint32_t w=(m>>5);  // w=m/32\n");
       fprintf(f,"     a0=N.v[w];\n");    
       fprintf(f,"     if (w<%u) a1=N.v[w+1]; else a1=0;\n",N-1);    
       fprintf(f,"     if (w<%u) a2=N.v[w+2]; else a2=0;\n",N-2);    
    }
    fprintf(f,"     m=(m&31); // m=m mod 32\n");
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"shf.r.clamp.b32 %%0, %%0, %%1, %%3;\\n\\t\"\n");    
    fprintf(f,"          \"shf.r.clamp.b32 %%1, %%1, %%2, %%3;\\n\\t\"\n");    
    fprintf(f,"          \"shr.b32 %%2, %%2, %%3;\\n\\t\"\n");     
    fprintf(f,"          : \"+r\"(a0),\"+r\"(a1), \"+r\"(a2)\n");
    fprintf(f,"          : \"r\"(m));\n");     
    fprintf(f,"     return ((((uint64_t) a1)<<32)|(a0));\n}\n\n");
}


void gera_add_uint(FILE *f, uint32_t nw) {
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    fprintf(f,"__device__ bt_uint%u_t add_uint%u (bt_uint%u_t a, bt_uint%u_t b) {\n",nw,nw,nw,nw);
    fprintf(f,"     bt_uint%u_t res;\n",nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"add.cc.u32      %%0, %%%u, %%%u;\\n\\t\"\n",N,DN);
    for (uint32_t i=1;i<N-1;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,N+i,DN+i);
    fprintf(f,"          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,DN-1,N+DN-1);
    //     fprintf(f,"          \"}\"\n");
    fprintf(f,"          : ");
    print_regs(f,nw,'=',"res");
    fprintf(f,"\n          : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,",\n           ");
    print_regs(f,nw,' ',"b");
    fprintf(f,");\n");
    fprintf(f,"      return res;\n}\n\n");
}

void gera_equal_uint(FILE *f, uint32_t nw) {
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ uint32_t equal_uint%u (bt_uint%u_t a, bt_uint%u_t b) {\n",nw,nw,nw,nw);
    fprintf(f,"     uint32_t res=0,aux=0;\n",nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
//     fprintf(f,"          \"xor.b32     %%0, %%0, %%0;\\n\\t\"\n");
    for (uint32_t i=0;i<N;i++) {
          fprintf(f,"          \"xor.b32     %%1, %%%u, %%%u;\\n\\t\"\n",2+i,N+2+i);
          fprintf(f,"          \"or.b32      %%0, %%0, %%1;\\n\\t\"\n");
    }
    fprintf(f,"          : \"+r\"(res), \"+r\"(aux)  ");
    fprintf(f,"\n          : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,",\n           ");
    print_regs(f,nw,' ',"b");
    fprintf(f,");\n");
    fprintf(f,"      return (res==0);\n}\n\n");
}



void gera_two_complement(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ bt_uint%u_t two_complement_uint%u (bt_uint%u_t a) {\n",nw,nw,nw);
    fprintf(f,"     bt_uint%u_t res;\n",nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
    for (uint32_t i=0;i<N;i++) fprintf(f,"          \"not.b32         %%%u, %%%u;\\n\\t\"\n",i,i+N);
    fprintf(f,"          \"add.cc.u32      %%0, %%0, 1;\\n\\t\"\n");
    for (uint32_t i=1;i<N-1;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, 0;\\n\\t\"\n",i,i);
    fprintf(f,"          \"addc.u32        %%%u, %%%u, 0;\\n\\t\"\n",N-1,N-1);
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'=',"res");
    fprintf(f,"\n         : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,");\n");
    fprintf(f,"      return res;\n}\n\n");
}

void gera_x2mod(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    fprintf(f,"__device__ bt_uint%u_t x2mod_uint%u (bt_uint%u_t a, bt_uint%u_t Ntc) {\n",nw,nw,nw,nw);
    fprintf(f,"    bt_uint%u_t s,sN;\n",nw);
    fprintf(f,"    uint32_t c;\n");
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"add.cc.u32      %%0, %%%u, %%%u;\\n\\t\"\n",DN+1,DN+1);
    for (uint32_t i=1;i<N-1;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,DN+1+i,DN+1+i);
    fprintf(f,"          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,DN+N,DN+N);
    fprintf(f,"          \"add.cc.u32      %%%u, %%%u, %%%u;\\n\\t\"\n",N,0,DN+N+1);
    for (uint32_t i=1;i<N;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",N+i,i,DN+N+1+i);
    fprintf(f,"          \"addc.u32        %%%u, 0, 0;\\n\\t\"\n",DN);
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'=',"s");
    fprintf(f,",\n           ");
    print_regs(f,nw,'=',"sN");
    fprintf(f,",\"=r\"(c)\n         : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,",\n           ");
    print_regs(f,nw,' ',"Ntc");
    fprintf(f,");\n");
    fprintf(f,"   if (c) return sN; else return s;\n");
    fprintf(f,"}\n\n");
}


void gera_if_ge_add(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    fprintf(f,"__device__ bt_uint%u_t  if_ge_add_uint%u(bt_uint%u_t a, bt_uint%u_t Ntc){\n",nw,nw,nw,nw);
    fprintf(f,"    uint32_t carry;\n");
    fprintf(f,"    bt_uint%u_t res;\n",nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"add.cc.u32      %%%u, %%%u, %%%u;\\n\\t\"\n",0,N+1,DN+1);
    for (uint32_t i=1;i<N;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,N+i+1,DN+1+i);
    fprintf(f,"          \"addc.u32        %%%u, 0, 0;\\n\\t\"\n",N);
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'=',"res");
    fprintf(f,",\"=r\"(carry)\n         : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,",\n           ");
    print_regs(f,nw,' ',"Ntc");
    fprintf(f,");\n");   
    fprintf(f,"     if (carry) return res; else return a;\n");
    fprintf(f,"}\n\n");
}


void gera_shiftR(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    fprintf(f,"__device__ bt_uint%u_t shiftR_%u(bt_uint%u_t a) {\n",nw,nw,nw);
    fprintf(f,"    bt_uint%u_t res;\n",nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
    for (uint32_t i=0;i<N-1;i++) fprintf(f,"          \"shf.r.clamp.b32 %%%u, %%%u, %%%u, 1;\\n\\t\"\n",i,N+i,N+i+1);
    fprintf(f,"          \"shf.r.clamp.b32 %%%u, %%%u,  0, 1;\\n\\t\"\n",N-1,DN-1);
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'=',"res");
    fprintf(f,"\n         : ");
    print_regs(f,nw,' ',"a");
    fprintf(f,");\n");   
    fprintf(f,"    return res;\n");
    fprintf(f,"}\n\n");    
}

void gera_inv_mod_pow2(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ bt_uint%u_t inv_mod_pow2_%u(bt_uint%u_t x){\n",nw,nw,nw);
    fprintf(f,"    bt_uint%u_t y,xc=x;\n",nw);
    fprintf(f,"    uint32_t u=0x40000000; // set MSB and shift right\n");
    fprintf(f,"    xc=shiftR_%u(xc);\n",nw);
    fprintf(f,"    for (uint32_t i=1;i<31;i++) {\n");
    fprintf(f,"        if (xc.b0&1) {\n");  
    fprintf(f,"          xc=add_uint%u(xc,x);\n",nw);
    fprintf(f,"          u=u|0x80000000;  //set MSB\n");
    fprintf(f,"        }\n");
    fprintf(f,"        xc=shiftR_%u(xc);\n",nw);
    fprintf(f,"        u=u>>1;\n");    
    fprintf(f,"    }\n");
    fprintf(f,"    if (xc.b0&1) {\n");
    fprintf(f,"       xc=add_uint%u(xc,x);\n",nw);
    fprintf(f,"       u=u|0x80000000;  //set MSB\n");
    fprintf(f,"    }\n");
    fprintf(f,"    y.v[0]=u;\n");
    fprintf(f,"    for (uint32_t j=1; j<%u;j++) {\n",N);
    fprintf(f,"        xc=shiftR_%u(xc);\n",nw);
    fprintf(f,"        u=0;\n");
    fprintf(f,"        for (uint32_t i=0;i<31;i++) {\n");
    fprintf(f,"            if (xc.b0&1) {\n");  
    fprintf(f,"              xc=add_uint%u(x,xc);\n",nw);
    fprintf(f,"              u=u|0x80000000;  //set MSB\n");
    fprintf(f,"            }\n");
    fprintf(f,"            xc=shiftR_%u(xc);\n",nw);
    fprintf(f,"            u=u>>1;\n");    
    fprintf(f,"        }\n");
    fprintf(f,"        if (xc.b0&1) {\n");
    fprintf(f,"           xc=add_uint%u(x,xc);\n",nw);
    fprintf(f,"           u=u|0x80000000;  //set MSB\n");
    fprintf(f,"        }\n");
    fprintf(f,"        y.v[j]=u;\n");
    fprintf(f,"    }\n    return y;\n");
    fprintf(f,"}\n\n");
}



void gera_mulmod(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N
    
    zera();
    for (uint32_t i=0;i<N;i++)  gera_linha(nw,i); 
    
    //zera operações entre N e DN
    for (uint32_t i=N;i<DN;i++) 
        for (uint32_t j=0;j<DN_MAX;j++) {
            ops[i][j]=0;
            opi[i][j]=0;
            HL[i][j]=0;
        }  
        
        //corrige indices registradores entre 0 e N
        for (uint32_t i=0;i<N;i++) 
            for (uint32_t j=0;j<DN_MAX;j++) {
                if (ops[i][j]>0) ops[i][j]-=N;  
                if (opi[i][j]>0) opi[i][j]-=N;  
            }  
            
            
            marca_primeiro_ultimo(nw);
        fprintf(f,"// multiplication %u bits X %u bits mod 2^%u => %u bits\n",nw,nw,nw,nw,nw);
        mostra_mult(f,nw,N,0);
        fprintf(f,"__device__  bt_uint%u_t mulmod_%u_%u(bt_uint%u_t lo, bt_uint%u_t Ninv) {\n",nw,nw,nw,nw,nw);
        fprintf(f,"    bt_uint%u_t x;\n",nw);
        fprintf(f,"     // calculate x=lo*Ninv mod 2^%u\n",nw);
        fprintf(f,"     asm (\"\\n\\t\"\n");
        
        gera_asm_mult(f,nw,N);
        
        //    fprintf(f,"          \"}\"\n");
        fprintf(f,"         : ");
        print_regs(f,nw,'=',"x");
        fprintf(f,"\n         : ");
        print_regs(f,nw,' ',"lo");
        fprintf(f,",\n           ");
        print_regs(f,nw,' ',"Ninv");
        fprintf(f,");\n");   
        
        fprintf(f,"   return x;\n");
        fprintf(f,"}\n\n");
}


void gera_addcarry(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    fprintf(f,"__device__  bt_uint%u_t addcarry_uint%u(bt_uint%u_t x, bt_uint%u_t y,  uint32_t carry){\n",nw,nw,nw,nw);
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"add.cc.u32      %%%u, 0xFFFFFFFF, %%%u; \\n\\t\"   // acumulate carry\n",N,N);
    for (uint32_t i=0;i<N-1;i++) fprintf(f,"          \"addc.cc.u32     %%%u, %%%u, %%%u;\\n\\t\"\n",i,i,N+1+i);
    fprintf(f,"          \"addc.u32        %%%u, %%%u, %%%u;\\n\\t\"\n",N-1,N-1,DN);
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'+',"x");
    fprintf(f,",\"+r\"(carry)\n         : ");
    print_regs(f,nw,' ',"y");
    fprintf(f,");\n");   
    fprintf(f,"   return x;\n");
    fprintf(f,"}\n\n");
}

void gera_carry(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ uint32_t carry_%u(bt_uint%u_t x, bt_uint%u_t y){\n",nw,nw,nw);
    fprintf(f,"    uint32_t carry;\n");
    fprintf(f,"     asm (\"\\n\\t\"\n");
    fprintf(f,"          \"add.cc.u32      %%0, %%1, %%%u; \\n\\t\"\n",N+1);
    for (uint32_t i=1;i<N;i++) fprintf(f,"          \"addc.cc.u32     %%0, %%%u, %%%u;\\n\\t\"\n",i+1,N+i+1);
    fprintf(f,"          \"addc.u32        %%0, 0, 0;\\n\\t\"\n");
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : \"=r\"(carry)\n");
    fprintf(f,"         : ");
    print_regs(f,nw,' ',"x");
    fprintf(f,",\n           ");
    print_regs(f,nw,' ',"y");
    fprintf(f,");\n");   
    fprintf(f,"    return carry;\n");
    fprintf(f,"}\n\n");   
}

void gera_redc(FILE *f, uint32_t nw){
    fprintf(f,"__device__  bt_uint%u_t redc_%u(bt_uint%u_t hi, bt_uint%u_t lo, bt_uint%u_t N, bt_uint%u_t Ntc, bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw,nw,nw);
    fprintf(f,"   bt_uint%u_t x,rhi=hi,rlo=lo;\n",nw);
    fprintf(f,"   uint32_t carry;\n");   
    fprintf(f,"   x=mulmod_%u_%u(lo,Ninv);\n",nw,nw);   
    fprintf(f,"   mul_%u_%u(&rhi,&rlo,x,N);\n",nw,nw<<1);
    fprintf(f,"     // [x, - ]= [hi,lo]+[rhi,rlo]\n");
    fprintf(f,"   carry=carry_%u(lo,rlo);\n",nw);
    fprintf(f,"   x=addcarry_uint%u(hi,rhi,carry);\n",nw);
    fprintf(f,"   return if_ge_add_uint%u(x,Ntc);\n",nw);
    fprintf(f,"}\n\n");    
}


void gera_asm_square(FILE *f, uint32_t nw) {
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    char op[5];
    uint64_t cmult=0,cadd=0;
    uint8_t status_col[DN],carry;
    for (uint32_t j=0;j<DN;j++) status_col[j]=0;
    fprintf(f,"    // multiplies distinct operands\n");   
    for (uint32_t i=0;i<DN-1;i++) {
        uint32_t soma=0;
        carry=0;
        for (uint32_t j=0;j<DN;j++) soma+=ops[j][i];
        if (soma==0) continue;
        fprintf(f,"\n");
        for (uint32_t j=0;j<DN;j++) {
            if (ops[j][i]>0) {                
                if (status_col[j]==0) { // não existe valor anterior na coluna
                    carry=print_operacao_coluna_livre(f,i,j,DN,status_col,carry,&cadd,&cmult);
                } else {  //coluna tem valor anterior
                    carry=print_operacao_coluna_ocupada(f,i,j,DN,status_col,carry,&cadd,&cmult);
                }
            }
        }
    }
    fprintf(f,"\n    // duplicate sum of multiplications of different operands\n");
    
    ins_addcc(f,"%1","%1","%1");
    for (uint32_t j=2;j<DN-1;j++) {
        sprintf(op,"%%%u",j);
        ins_addccc(f,op,op,op);
    }
    sprintf(op,"%%%u",DN-1);
    if (status_col[DN-1]) ins_addc(f,op,op,op); else ins_addc(f,op,"0","0");
    cadd+=DN;
    
    fprintf(f,"\n    // multiplies equal operands and sum at previous value\n"); 
    carry=print_operacao_coluna_livre(f,DN-1,0,DN,status_col,0,&cadd,&cmult);
    for (uint32_t j=1;j<DN;j++)
        carry=print_operacao_coluna_ocupada(f,DN-1,j,DN,status_col,carry,&cadd,&cmult);    
    
    fprintf(f,"\n             // %lu additions and %lu multiplications\n",cadd,cmult);
}


void gera_square(FILE *f, uint32_t nw){
    uint32_t DN,N;
    N=(nw>>5);  // número de palavras
    DN=(N<<1);  // dobro de N    
    zera();
    // produtos distintos
    for (uint32_t i=1;i<N;i++) {
        uint32_t linha=2*i+1; 
        for (uint32_t j=0;j<i;j++) {
            uint32_t pos=i+j;        
            uint32_t lindest=linha_vazia(pos,linha);
            ops[pos][lindest]=DN+j+1;
            opi[pos][lindest]=DN+i+1;
            ops[pos+1][lindest]=DN+j+1;
            opi[pos+1][lindest]=DN+i+1;
            HL[pos+1][lindest]=1;     
        }
    }
    inverte_mult(f,nw);
    // quadrados na última linha
    for (uint32_t j=0;j<N;j++) {
        ops[j<<1][DN-1]=DN+j+1;
        opi[j<<1][DN-1]=DN+j+1;
        ops[(j<<1)+1][DN-1]=DN+j+1;
        opi[(j<<1)+1][DN-1]=DN+j+1;
        HL[(j<<1)+1][DN-1]=1;     
    }
    marca_primeiro_ultimo(nw);    
    fprintf(f,"// square %u bits mod 2^%u => %u bits\n",nw,nw,nw);
    mostra_mult(f,nw,DN,1);
    
    fprintf(f,"__device__ bt_uint%u_t square_%u(bt_uint%u_t y, bt_uint%u_t N, bt_uint%u_t Ntc, bt_uint%u_t Ninv) {\n",nw,nw,nw,nw,nw,nw);
    fprintf(f,"    bt_uint%u_t hi,lo;\n",nw);
    fprintf(f,"    // calculate y^2\n");
    fprintf(f,"     asm (\"\\n\\t\"\n");
    gera_asm_square(f,nw);   
    //    fprintf(f,"          \"}\"\n");
    fprintf(f,"         : ");
    print_regs(f,nw,'=',"lo");
    fprintf(f,",\n           ");
    print_regs(f,nw,'=',"hi");
    fprintf(f,"\n         : ");
    print_regs(f,nw,' ',"y");
    fprintf(f,");\n");   
    
    fprintf(f,"   return redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"}\n\n");
    
}

void gera_power(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ bt_uint%u_t power_%u(uint32_t a, uint32_t M,bt_uint%u_t N,bt_uint%u_t Ntc, bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
    fprintf(f,"    bt_uint%u_t y={a",nw);
    for (uint32_t i=1;i<N;i++) fprintf(f,",0");
    fprintf(f,"};\n");
    fprintf(f,"    for (uint32_t j=0;j<%u;j++)  {  //calcule y=a*2^%u mod N\n",nw,nw);
    fprintf(f,"        y=x2mod_uint%u(y,Ntc);\n",nw);
    fprintf(f,"    }\n");
    fprintf(f,"    for (uint32_t j=0;j<=M;j++)  {\n");
    fprintf(f,"        y=square_%u(y,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    }\n");
    fprintf(f,"    return y;\n");
    fprintf(f,"}\n\n");
}




void gera_calculate_power_prime(FILE *f, uint32_t nw){
    fprintf(f,"__device__ void calculate_power_prime_%u(bt_uint%u_t *abp, uint32_t M, bt_uint%u_t N,bt_uint%u_t Ntc,bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
    fprintf(f,"     // prime powers in Montogomery Form\n");
    fprintf(f,"     abp[0]=power_%u(2,M,N,Ntc,Ninv);\n",nw);
    fprintf(f,"     abp[1]=power_%u(3,M,N,Ntc,Ninv);\n",nw);
    fprintf(f,"     abp[3]=power_%u(5,M,N,Ntc,Ninv);\n",nw);
    fprintf(f,"     abp[5]=power_%u(7,M,N,Ntc,Ninv);\n",nw);
    fprintf(f,"     abp[9]=power_%u(11,M,N,Ntc,Ninv);\n",nw);
    fprintf(f,"}\n\n");    
}

void gera_calculate_power_composite(FILE *f, uint32_t nw){
    fprintf(f,"__device__ void calculate_power_composite_%u(bt_uint%u_t *abp, uint32_t M, bt_uint%u_t N,bt_uint%u_t Ntc,bt_uint%u_t Ninv){\n",nw,nw,nw,nw,nw);
    fprintf(f,"        bt_uint%u_t hi,lo;\n",nw);  
    fprintf(f,"        // another powers in Montogomery Form\n");
    fprintf(f,"        mul_%u_%u(&hi,&lo,abp[0],abp[1]);\n",nw,nw<<1);
    fprintf(f,"        abp[4]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);
    
    fprintf(f,"        mul_%u_%u(&hi,&lo,abp[0],abp[2]);\n",nw,nw<<1);
    fprintf(f,"        abp[6]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);
    
    fprintf(f,"        mul_%u_%u(&hi,&lo,abp[0],abp[3]);\n",nw,nw<<1);
    fprintf(f,"        abp[8]=redc_%u(hi,lo,N,Ntc,Ninv);\n\n",nw);
    
    fprintf(f,"        mul_%u_%u(&hi,&lo,abp[1],abp[2]);\n",nw,nw<<1);
    fprintf(f,"        abp[10]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"}\n\n");
}



void gera_verify(FILE *f, uint32_t nw) {
    uint32_t N;
    N=(nw>>5);  // número de palavras
    fprintf(f,"__device__ uint8_t verify_%u(bt_uint%u_t *abp, bt_uint%u_t Ntc){\n",nw,nw,nw);
    fprintf(f,"    bt_uint%u_t one={1",nw);
    for (uint32_t i=1;i<N;i++) fprintf(f,",0");
    fprintf(f,"};\n");
    fprintf(f,"    for (uint32_t j=0;j<%u;j++)  {  //calcule y=2^%u mod N\n",nw,nw);
    fprintf(f,"       one=x2mod_uint%u(one,Ntc);\n",nw);
    fprintf(f,"    }\n");            
    fprintf(f,"    uint8_t res=0;\n");        
    fprintf(f,"    for (uint8_t j=0;j<NUM_AB;j++) {\n");    
    fprintf(f,"        bt_uint%u_t ap=abp[av[j]-2],bp;\n",nw);    
    fprintf(f,"        if (bv[j]==1) bp=one; else bp=abp[bv[j]-2];\n");    
    fprintf(f,"        res+=((ap.b0==bp.b0)");    
    for (uint32_t i=1;i<N;i++) fprintf(f,"&&(ap.b%u==bp.b%u)",i,i);    
    fprintf(f,");\n");    
    fprintf(f,"    }\n");            
    fprintf(f,"    return res;\n");    
    fprintf(f,"}\n\n");    
}


void gera_xGF(FILE *f, uint32_t nw) {
    fprintf(f,"__global__ void xGF_%u(uint32_t M){\n",nw);
    fprintf(f,"    uint32_t ind=threadIdx.x; //candidate index\n");
    fprintf(f,"    uint32_t indBloc=blockIdx.x; //block index\n");
    fprintf(f,"    if (ind<numCand[indBloc]) {\n");
    fprintf(f,"        bt_uint%u_t abpower[11];// 2 to 12 power array\n",nw);
    fprintf(f,"        bt_uint%u_t N,Ntc,Ninv;\n",nw);        
    fprintf(f,"        N=cand_%u[indBloc][ind];\n",nw);
    fprintf(f,"        Ntc=two_complement_uint%u(N);\n",nw);
    fprintf(f,"        // calculate -(N^-1 mod 2^s)\n");
    fprintf(f,"        Ninv=two_complement_uint%u(inv_mod_pow2_%u(N));\n",nw,nw);
    fprintf(f,"        calculate_power_prime_%u(abpower,M,N,Ntc,Ninv);\n",nw);   
    fprintf(f,"        abpower[2]=square_%u(abpower[0],N,Ntc,Ninv);\n",nw);
    fprintf(f,"        abpower[7]=square_%u(abpower[1],N,Ntc,Ninv);\n",nw);        
    fprintf(f,"        calculate_power_composite_%u(abpower,M,N,Ntc,Ninv);\n",nw);        
    fprintf(f,"        if (verify_%u(abpower,Ntc)) {\n",nw);
    fprintf(f,"           uint32_t pos=atomicAdd(&numChecked,1);\n");
    fprintf(f,"           checkCand_%u[pos]=N;\n",nw);
    fprintf(f,"        }\n");   
    fprintf(f,"    }\n");    
    fprintf(f,"}\n\n");   
}


void gera_prp(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras
// fprintf(f,"#ifndef MAX_DEBUG\n");
// fprintf(f,"#define MAX_DEBUG 200000\n");
// fprintf(f,"#endif\n");
// fprintf(f,"__device__ __managed__  bt_uint%u_t   CA_%u[MAX_DEBUG], POW_%u[MAX_DEBUG],ONE_%u[MAX_DEBUG];\n",nw,nw,nw,nw);
// fprintf(f,"__device__ __managed__ uint32_t  topDEBUG=0,BL_%u[MAX_DEBUG],TRBL_%u[MAX_DEBUG];\n",nw,nw);
// fprintf(f,"__device__ __managed__ uint64_t NC_%u[MAX_DEBUG];\n",nw);
    
    fprintf(f,"__global__ void prp_test_%u(uint32_t M){\n",nw);    
    fprintf(f,"    uint32_t ind=threadIdx.x; //candidate index\n");
    fprintf(f,"    uint32_t indBloc=blockIdx.x; //block index\n");
    fprintf(f,"    if (ind<numCand[indBloc]) {\n");
    fprintf(f,"        uint32_t bc=0;\n");
    fprintf(f,"        uint64_t k;\n");
    fprintf(f,"        bt_uint%u_t y={13",nw);
    for (uint32_t i=1;i<N;i++) fprintf(f,",0");
    fprintf(f,"}, one={1");
    for (uint32_t i=1;i<N;i++) fprintf(f,",0");
    fprintf(f,"}, N, Ninv, Ntc,power;\n");   
    fprintf(f,"\n");    
    fprintf(f,"        N=cand_%u[indBloc][ind];\n",nw);
    fprintf(f,"        k=bt%u_kn(N, M);\n",nw);
// fprintf(f,"     uint64_t aux=k;\n");
    fprintf(f,"        Ntc=two_complement_uint%u(N);\n",nw);
    fprintf(f,"            // calculate -(N^-1 mod 2^s)\n");
    fprintf(f,"        Ninv=two_complement_uint%u(inv_mod_pow2_%u(N));\n",nw,nw);
    fprintf(f,"\n");    
    fprintf(f,"        for (uint32_t j=0;j<%u;j++)  {  //calculate y=13*2^%u mod N  and one=2^%u mod N\n",nw,nw,nw);
    fprintf(f,"            y=x2mod_uint%u(y,Ntc);\n",nw);
    fprintf(f,"            one=x2mod_uint%u(one,Ntc);\n",nw);
    fprintf(f,"        }\n");
    fprintf(f,"\n");    
    fprintf(f,"        //calculate y^k mod N in Montogomery form\n");
    fprintf(f,"        bc=0;\n"); 
    fprintf(f,"        while ((bc<64) && ((k&(1ULL<<63))==0)) {\n");
    fprintf(f,"            k=k<<1;\n");
    fprintf(f,"            bc++;\n");
    fprintf(f,"        }\n");
    fprintf(f,"        power=y;\n");    
    fprintf(f,"        while (bc<63) {\n");
    fprintf(f,"            bt_uint%u_t hi,lo;\n",nw);
    fprintf(f,"            k=k<<1;\n");
    fprintf(f,"            bc++;\n");
    fprintf(f,"            power=square_%u(power,N,Ntc,Ninv);\n",nw);
    fprintf(f,"            if (k&(1ULL<<63)) {\n");
    fprintf(f,"              //multiplies power=power*y mod N\n");
    fprintf(f,"              mul_%u_%u(&hi,&lo,power,y);\n",nw,nw<<1);
    fprintf(f,"              power=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"            }\n"); 
    fprintf(f,"        }\n");
    fprintf(f,"         //calculate (y^k)^(2^m) mod N in Montogomery form \n");   
    fprintf(f,"        for (uint32_t j=0;j<=M;j++)  {\n");
    fprintf(f,"            power=square_%u(power,N,Ntc,Ninv);\n",nw);
    fprintf(f,"        }\n");
    
    
// fprintf(f,"            uint32_t pos=atomicAdd(&topDEBUG,1);\n");
// fprintf(f,"            CA_%u[pos]=N;\n",nw);
// fprintf(f,"            NC_%u[pos]=aux;\n",nw);
// fprintf(f,"            POW_%u[pos]=power;\n",nw);
// fprintf(f,"            ONE_%u[pos]=one;\n",nw);
// fprintf(f,"            BL_%u[pos]=indBloc;\n",nw);
// fprintf(f,"            TRBL_%u[pos]=ind;\n",nw);
    
    
    fprintf(f,"        if (!equal_uint%u(power,one)){\n",nw);    
    fprintf(f,"           cand_%u[indBloc][ind].b0=0; // indicates that it is not PRP\n",nw);
    fprintf(f,"        }\n");       

    
//     if (N<10) {
//         fprintf(f,"        if ((power.b0!=one.b0)");    
//         for (uint32_t i=1;i<N;i++) fprintf(f,"||(power.b%u!=one.b%u)",i,i);    
//         fprintf(f,"){\n");     
//         fprintf(f,"           cand_%u[indBloc][ind].b0=0; // indicates that it is not PRP\n",nw);
//         fprintf(f,"        }\n");   
//     } else {
//         fprintf(f,"        for (uint32_t j=0;j<%u;j++)  {\n",N);
//         fprintf(f,"          if (power.v[j]!=one.v[j]) {\n");    
//         fprintf(f,"             cand_%u[indBloc][ind].b0=0; // indicates that it is not PRP\n",nw);
//         fprintf(f,"             cand_%u[indBloc][ind].b1=j;\n",nw);
//         fprintf(f,"             break;\n");
//         fprintf(f,"          }//if\n");   
//         fprintf(f,"        }//for\n");   
//     }
    fprintf(f,"    }\n");    
    fprintf(f,"}\n\n");   
}

void gera_eliminate_composite(FILE *f, uint32_t nw){
    fprintf(f,"__global__ void eliminate_composite_%u(void){ // 1 thread for each block\n",nw);    
    fprintf(f,"    uint32_t indBloc=blockIdx.x; //block index\n");    
    fprintf(f,"    uint32_t bottom=0,top=numCand[indBloc];\n");
    fprintf(f,"    bt_uint%u_t *pos=cand_%u[indBloc];// first position block\n",nw,nw);
    fprintf(f,"    if (top>0) {\n");    
    fprintf(f,"      top--;\n");    
    fprintf(f,"      do {\n");
    fprintf(f,"          while ((bottom<top) && (pos[bottom].b0!=0)) {  //find next with b0==0\n");
    fprintf(f,"              bottom++;\n");
    fprintf(f,"          }\n");
    fprintf(f,"          if (bottom<top) {\n");
    fprintf(f,"              while ((bottom<top) && (pos[top].b0==0)) {//search next in top with b0>0\n");
    fprintf(f,"                  top--;\n");
    fprintf(f,"              }\n");
    fprintf(f,"              if (bottom<top) { //copy to bottom\n");
    fprintf(f,"                  pos[bottom]=pos[top];\n");
    fprintf(f,"                  bottom++;\n");
    fprintf(f,"                  top--;\n");
    fprintf(f,"              }\n");
    fprintf(f,"         }\n");
    fprintf(f,"         if ((bottom==top)&& (pos[bottom].b0!=0)) bottom++;\n");
    fprintf(f,"      } while (bottom<top);\n");
    fprintf(f,"      numCand[indBloc]=bottom;\n");
    fprintf(f,"    }\n");     
    fprintf(f,"}\n\n");   
}

void gera_regroup_candidates(FILE *f, uint32_t nw){
    fprintf(f,"__global__ void regroup_candidates_%u(void){ // 1 thread for each block\n",nw);    
    fprintf(f,"    uint32_t regBloc,indBloc=blockIdx.x; //block index\n");    
    fprintf(f,"    uint32_t top=numCand[indBloc];\n");
    fprintf(f,"    if (top<SizeBlockCand_%u) { // available space\n",nw);
    fprintf(f,"      bt_uint%u_t *pos=cand_%u[indBloc];// first position block\n",nw,nw);
    fprintf(f,"      do {\n");    
    fprintf(f,"        regBloc=atomicAdd(&nextRegroupBlock,1);\n");
    fprintf(f,"        if (regBloc<NUM_BLOCK_CAND){ // numRegroupBlocks < regBlock < NUM_BLOCK_CAND\n",nw);
    fprintf(f,"            bt_uint%u_t *posRegBloc=cand_%u[regBloc];// first position regblock\n",nw,nw);
    fprintf(f,"            uint32_t topRegBloc=numCand[regBloc];\n");
    fprintf(f,"            while ((top<SizeBlockCand_%u) && (topRegBloc>0)) {\n",nw);
    fprintf(f,"                pos[top]=posRegBloc[topRegBloc-1];// copy candidate\n");
    fprintf(f,"                top++;\n"); 
    fprintf(f,"                topRegBloc--;\n"); 
    fprintf(f,"            }//while\n");     
    fprintf(f,"            numCand[indBloc]=top;\n");    
    fprintf(f,"            numCand[regBloc]=topRegBloc;\n");    
    fprintf(f,"        }//if (regBloc<NUM_BLOCK_CAND)\n");     
    fprintf(f,"      } while ((top<SizeBlockCand_%u) && (regBloc<NUM_BLOCK_CAND));\n",nw);    
    fprintf(f,"    }// if (top<SizeBlockCand_%u) \n",nw);     
    fprintf(f,"}\n\n");   
}


void gera_fill_cand(FILE *f, uint32_t nw){
    fprintf(f,"__global__ void fill_cand_%u(uint32_t n){\n",nw);
    fprintf(f,"    unsigned char *tab=d_tab_data[n];\n");
    fprintf(f,"    uint32_t indBloc=blockIdx.x; //index block Cand\n");
    fprintf(f,"    uint64_t k0,k1,i,dK,nc,kindB;\n"); 
    fprintf(f,"    uint64_t kmax=kCurrent+kStep;\n"); 
    fprintf(f,"    uint64_t sizeBlock=(kStep+NUM_BLOCK_CAND-1)/NUM_BLOCK_CAND;\n");
    fprintf(f,"    bt_uint%u_t *pos; // position in cand_%u\n",nw,nw);
    fprintf(f,"    k0=kCurrent+(indBloc*sizeBlock);\n");
    fprintf(f,"    if ((k0&1)==0) k0++;\n");
    fprintf(f,"    k1=k0+sizeBlock;\n");
    fprintf(f,"    if (k1>kmax) k1=kmax;\n");    
    fprintf(f,"    kindB=kind[indBloc];\n");
    fprintf(f,"    if (kindB<k0) kindB=k0;\n");
    fprintf(f,"    i=(kindB-kCurrent)>>1;  // position in bitmap\n");
    fprintf(f,"    dK=(k1-kCurrent)>>1;    // max position in bitmap\n");
    fprintf(f,"    nc=0;\n");
    fprintf(f,"    pos=cand_%u[indBloc];// first position block\n",nw);        
    fprintf(f,"    while (i<dK) {\n");
    fprintf(f,"        if (tab[i>>3]&((uint8_t)(1<<(i&7))))  { //is candidate\n");
//     fprintf(f,"          if (prp_%u(kindB,n+nCurrent)) { // prp only\n",nw);     
    fprintf(f,"            *pos=kn_bt%u(kindB,n+nCurrent); // *pos<=>cand_%u[indBlock][nc]\n",nw,nw,nw);  
    fprintf(f,"            nc++;\n");
    fprintf(f,"            pos++; //next position\n");
    fprintf(f,"            if (nc==SizeBlockCand_%u) {\n",nw);
    fprintf(f,"                kindB+=2;\n");
//     fprintf(f,"                numCand[indBloc]=nc; \n");
    fprintf(f,"                break; \n");
    fprintf(f,"            }  \n");
//     fprintf(f,"          } \n");
    fprintf(f,"        } \n");
    fprintf(f,"        i++; \n");
    fprintf(f,"        kindB+=2; \n");
    fprintf(f,"    }  \n");
    fprintf(f,"    numCand[indBloc]=nc;\n");
    fprintf(f,"    kind[indBloc]=kindB; \n");
    fprintf(f,"}\n\n");       
}

void gera_uinttompz(FILE *f, uint32_t nw){
    uint32_t N;
    N=(nw>>5);  // número de palavras 
    fprintf(f,"void uint%utompz(mpz_t x,bt_uint%u_t v){\n",nw,nw);
    fprintf(f,"   //bt_uint%u_t to mpz\n",nw);
    fprintf(f,"   mpz_set_ui(x,v.b%u);\n",N-1);
    for (uint32_t j=N-1;j>0;j--) {
        fprintf(f,"   mpz_mul_2exp(x,x,32);\n");
        fprintf(f,"   mpz_add_ui(x,x,v.b%u);\n",j-1);  
    }
    fprintf(f,"}\n\n");
}

void gera_check(FILE *f, uint32_t nw){
    fprintf(f,"void check_%u(bt_uint%u_t x, uint32_t M) {\n",nw,nw);
    fprintf(f,"   mpz_t k,a,km;\n");
    fprintf(f,"   mpz_inits(a,km,k,0);\n");
    fprintf(f,"   uint%utompz(k,x);\n",nw);
    fprintf(f,"   // is 13-PRP ?\n");
    fprintf(f,"   mpz_set_ui(a,13);\n");
    fprintf(f,"   mpz_sub_ui(km,k,1);\n");
    fprintf(f,"   mpz_powm(a,a,km,k);\n");
    fprintf(f,"   if (mpz_cmp_ui(a,1)==0) { // if is 13-PRP\n");
    fprintf(f,"        mpz_fdiv_q_2exp(k,k,M);\n");
    fprintf(f,"        test_xGF_power_gmp(k, M);\n");
    fprintf(f,"   }\n");
    fprintf(f,"   mpz_clears(a,km,k,0);\n}\n\n");
}


void gera_head_tst(FILE *f, uint32_t nw){
    fprintf(f,"__device__ __managed__ bt_uint%u_t res, rN, rNinv,ry,ab[11];\n\n",nw);
}

void gera_tst(FILE *f, uint32_t nw){    
    fprintf(f,"__global__ void tst(void){\n");
    fprintf(f,"    bt_uint%u_t N,Ntc, Ninv,z;\n",nw);
    fprintf(f,"    z.b0=0; z.b1=0; z.b2=0;z.b3=0;\n");
    fprintf(f,"    N.b3=0x678; N.b2=0xce69b000; N.b1=0; N.b0=1;\n");
    fprintf(f,"//     N.b0=123456791; N.b1=32142; N.b2=3241;N.b3=5647;\n");
    fprintf(f,"    rN=N;\n");
    fprintf(f,"    Ntc=two_complement_uint%u(N);\n",nw);
    fprintf(f,"    Ninv=two_complement_uint%u(inv_mod_pow2_%u(N));\n",nw,nw); 
    fprintf(f,"    rNinv=Ninv;\n");
    fprintf(f,"    ab[0]=power_%u(2,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[1]=power_%u(3,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[3]=power_%u(5,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[5]=power_%u(7,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[9]=power_%u(11,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[7]=square_%u(ab[1],N,Ntc,Ninv);\n",nw);
    fprintf(f,"    ab[2]=square_%u(ab[0],N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");
    fprintf(f,"        {\n");
    fprintf(f,"          bt_uint%u_t hi,lo;\n",nw);
    fprintf(f,"          mul_%u_%u(&hi,&lo,ab[0],ab[1]);\n",nw,nw<<1);
    fprintf(f,"          ab[4]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");
    fprintf(f,"          mul_%u_%u(&hi,&lo,ab[0],ab[2]);\n",nw,nw<<1);
    fprintf(f,"          ab[6]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");
    fprintf(f,"          mul_%u_%u(&hi,&lo,ab[0],ab[3]);\n",nw,nw<<1);
    fprintf(f,"          ab[8]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");
    fprintf(f,"          mul_%u_%u(&hi,&lo,ab[1],ab[2]);\n",nw,nw<<1);
    fprintf(f,"          ab[10]=redc_%u(hi,lo,N,Ntc,Ninv);\n",nw);
    fprintf(f,"        }\n");
    fprintf(f,"\n");    
    fprintf(f,"//     for (uint32_t j=0;j<11; j++) \n");
    fprintf(f,"//       ab[j]=redc_%u(z,ab[j],N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");    
    fprintf(f,"    res=power_%u(9,75,N,Ntc,Ninv);\n",nw);
    fprintf(f,"\n");    
    fprintf(f,"}\n");
    fprintf(f,"\n");
    fprintf(f,"void teste_Mont_%u(void){\n",nw);
    fprintf(f,"    mpz_t aux;\n");
    fprintf(f,"    mpz_init(aux);\n");
    fprintf(f,"   tst<<<1,1>>>();\n");
    fprintf(f,"   cudaDeviceSynchronize();\n");
    fprintf(f,"   uint%utompz(aux,rN);\n",nw);
    fprintf(f,"   gmp_fprintf(f,\"N= %%Zd\\n\",aux);\n");
    fprintf(f,"   uint%utompz(aux,rNinv);\n",nw);
    fprintf(f,"   gmp_fprintf(f,\"Ninv= %%Zd\\n\",aux);\n");
    fprintf(f,"   uint%utompz(aux,ry);\n",nw);
    fprintf(f,"   gmp_fprintf(f,\"y= %%Zd\\n\",aux);\n");
    fprintf(f,"   uint%utompz(aux,res);\n",nw);
    fprintf(f,"   gmp_fprintf(f,\"res= %%Zd\\n\",aux);\n");
    fprintf(f,"   for (uint32_t j=0;j<11; j++) {\n");
    fprintf(f,"     uint%utompz(aux,ab[j]);\n",nw);
    fprintf(f,"     gmp_fprintf(f,\"pot %%u = %%Zd\\n\",j+2,aux);\n");
    fprintf(f,"   }\n");
    fprintf(f,"\n");
    fprintf(f,"\n");   
    fprintf(f,"   mpz_clear(aux);\n");
    fprintf(f,"   exit(1);\n");
    fprintf(f,"}\n\n");
    
}


void WriteKernel(uint32_t nw){
    FILE *f;
    char nameFile[128];
    sprintf(nameFile,"bt%ubits.cu",nw);
    f=fopen(nameFile,"wt");
    if (f==NULL) {
        fprintf(stderr,"Can not create file %s\n",nameFile);
        exit(1);
    }   
    fprintf(f,"\n");
    gera_tipo_base_cabecalho(f,nw);
    //    if (nw==192) gera_head_tst();
    gera_kn_bt(f,nw);
    gera_bt_kn(f,nw);
    gera_add_uint(f,nw);
    gera_equal_uint(f,nw);
    gera_two_complement(f,nw);
    gera_x2mod(f,nw);
    gera_if_ge_add(f,nw);
    gera_shiftR(f,nw);
    gera_inv_mod_pow2(f,nw);
    gera_mult(f,nw);
    gera_mulmod(f,nw);
    gera_addcarry(f,nw);
    gera_carry(f,nw);
    gera_redc(f,nw);
    gera_square(f,nw);
    gera_power(f,nw);
    gera_calculate_power_prime(f,nw);
    gera_calculate_power_composite(f,nw);
    gera_verify(f,nw); 
    gera_xGF(f,nw);
    gera_prp(f,nw);
    gera_eliminate_composite(f,nw);
    gera_regroup_candidates(f,nw);
    gera_fill_cand(f,nw);  
    gera_uinttompz(f,nw);
    //    gera_check(); 
    //    if (nw==192) gera_tst();
    fclose(f);
}
