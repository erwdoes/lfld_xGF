#ifndef TEMPO_H
#define TEMPO_H

#include <stddef.h> 
#include<sys/time.h>

double getTime(void);

#endif
