void choose_kernel(uint64_t k, uint64_t M){
    uint32_t num_bits=bits_size(k,M);
    if (num_bits<64)  {kernel=64; return;}
    if (num_bits<96)  {kernel=96; return;}
    if (num_bits<128)  {kernel=128; return;}
    if (num_bits<160)  {kernel=160; return;}
    if (num_bits<192)  {kernel=192; return;}
    if (num_bits<224)  {kernel=224; return;}
    if (num_bits<256)  {kernel=256; return;}
    if (num_bits<288)  {kernel=288; return;}
    if (num_bits<320)  {kernel=320; return;}
    if (num_bits<352)  {kernel=352; return;}
    if (num_bits<384)  {kernel=384; return;}
    if (num_bits<416)  {kernel=416; return;}
    kernel=0;
}
