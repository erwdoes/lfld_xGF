#ifndef STR2UINT64_C
#define STR2UINT64_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "str2uint64.h"

uint64_t str_2_uint64(const char *str){
   char aux[1000];
   int fim=strlen(str);
   strcpy(aux,str);   
   switch (str[fim-1]) {
       case 'E' : // 10^18
               strcpy(&(aux[fim-1]),"000000000000000000");
               break;
       case 'P' : // 10^15
               strcpy(&(aux[fim-1]),"000000000000000");
               break;
       case 'T' : //10^12
               strcpy(&(aux[fim-1]),"000000000000");
               break;
       case 'G' : // 10^9
               strcpy(&(aux[fim-1]),"000000000");
               break;
       case 'M' : // 10^6
               strcpy(&(aux[fim-1]),"000000");
               break;
       case 'K' : //10^3
               strcpy(&(aux[fim-1]),"000");
               break;
   }
   return strtoull(aux,NULL,10);
}


char *uint64_2_str(char *str, uint64_t x){
   if (x%1000000000000000000UL==0) sprintf(str,"%luE",x/1000000000000000000UL);
   else if (x%1000000000000000UL==0) sprintf(str,"%luP",x/1000000000000000UL);
   else if (x%1000000000000UL==0) sprintf(str,"%luT",x/1000000000000UL);
   else if (x%1000000000UL==0) sprintf(str,"%luG",x/1000000000UL);
   else if (x%1000000UL==0) sprintf(str,"%luM",x/1000000UL);
   else if (x%1000UL==0) sprintf(str,"%luK",x/1000UL);
   else sprintf(str,"%lu",x);
   return str;
}

void fprintf_suffix(FILE *f,const char *str, uint64_t x){
    char suffix='.';
    if (x%1000UL==0) {x=x/1000UL; suffix='K';} else goto pr;
    if (x%1000UL==0) {x=x/1000UL; suffix='M';} else goto pr;
    if (x%1000UL==0) {x=x/1000UL; suffix='G';} else goto pr;
    if (x%1000UL==0) {x=x/1000UL; suffix='T';} else goto pr;
    if (x%1000UL==0) {x=x/1000UL; suffix='P';} else goto pr;
    if (x%1000UL==0) {x=x/1000UL; suffix='E';}
pr:    
    if (suffix=='.') fprintf(f,"%s%lu",str,x);
    else fprintf(f,"%s%lu%c",str,x,suffix);
}


#endif //STR2UINT64_C
