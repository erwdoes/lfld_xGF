#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "in_out.h"

#define xgf_NUM_AB 42
#define xgf_LIM_POWER 12

const uint8_t xgf_av[xgf_NUM_AB]={2,3,3,4,5,5,5,5,6,6,7,7,7,7,7,7,8,8,8,8,9,9,9,9,10,10,10,10,11,11,11,11,11,11,11,11,11,11,12,12,12,12};
const uint8_t xgf_bv[xgf_NUM_AB]={1,1,2,3,1,2,3,4,1,5,1,2,3,4,5,6,1,3,5,7,2,5,7,8, 1, 3, 7, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9,10, 1, 5, 7,11};

mpz_t va_gmp[xgf_LIM_POWER];

void init_va_gmp(void){
    for (uint32_t i=0;i<xgf_LIM_POWER;i++) mpz_init(va_gmp[i]);
}

void free_va_gmp(void){
    for (uint32_t i=0;i<xgf_LIM_POWER;i++) mpz_clear(va_gmp[i]);
}

uint32_t prime_or_prp(mpz_t p){
    mpz_t a,pot,k;
    uint32_t res,e;
    mpz_inits(a,k,pot,0);
    
    if (mpz_cmp_ui(p,1000)<0) {
        res=mpz_probab_prime_p(p,15);
    } else {
        // find k
        mpz_sub_ui(k,p,1);
        mpz_set_ui(pot,2);
        e=mpz_remove(k,k,pot);
        mpz_set_ui(pot,1);
        mpz_mul_2exp(pot,pot,e);
        
        if (mpz_cmp(k,pot)<0) { // proth test    
            // find a
            mpz_set_ui(a,3);
            while (mpz_jacobi(a,p)!=-1) mpz_add_ui(a,a,2);
            
            mpz_sub_ui(pot,p,1);
            mpz_fdiv_q_2exp(pot,pot,1);
            
            mpz_powm(a,a,pot,p);
            mpz_add_ui(a,a,1);
            if (mpz_cmp(a,p)==0) res=2; else res=0;
        } else { //prp  tests
            res=mpz_probab_prime_p(p,15);
            //         mpz_set_ui(a,2);
            //         mpz_sub_ui(pot,p,1);
            //         mpz_powm(a,a,pot,p);
            //         res=(mpz_cmp_ui(a,1)==0);        
            //         if (res) {
            //           mpz_set_ui(a,3);
            //           mpz_sub_ui(pot,p,1);
            //           mpz_powm(a,a,pot,p);
            //           res=(mpz_cmp_ui(a,1)==0);        
            //         }
            //         if (res) {
            //           mpz_set_ui(a,5);
            //           mpz_sub_ui(pot,p,1);
            //           mpz_powm(a,a,pot,p);
            //           res=(mpz_cmp_ui(a,1)==0);        
            //         }
            //         if (res) res=2;  // probable
        }
    }
    mpz_clears(a,k,pot,0);
    return res;
} 


void test_xGF_gmp(mpz_t k, uint64_t M, uint64_t a, uint64_t b, uint32_t prime_prp){
    int test=0;
    unsigned long int j;
    mpz_t p,abi,aux;
    
    mpz_inits(p,abi,aux,0);
    
    mpz_set(p,k);
    mpz_mul_2exp(p,p,M);
    mpz_add_ui(p,p,1);
    
    mpz_set_ull(abi,b);
    mpz_invert(abi,abi,p);
    mpz_set_ull(aux,a);
    mpz_mul(abi,abi,aux);
    mpz_mod(abi,abi,p);
    // gera sequencia de restos
    for (j=0;j<M;j++) {
        mpz_powm_ui(abi,abi,2,p);
        test=(mpz_cmp_ui(abi,1)==0);
        if (test)  break;
    }
    if (test) writeFactor(k,a,b,M,j, prime_prp);
    mpz_clears(p,abi,aux,0);
}


int test_xGF_power_gmp(mpz_t p, uint32_t prime_prp){    
    mpz_t k,pm,aux;
    uint32_t M;
    mpz_inits(k,pm,aux,0);    

    mpz_sub_ui(pm,p,1);
    mpz_set_ui(aux,2);
    M=mpz_remove(k,pm,aux);
    
    mpz_set_ui(va_gmp[0],1);
    mpz_set_ui(aux,1);
    mpz_mul_2exp(aux,aux,M);
    for (uint32_t i=1;i<xgf_LIM_POWER;i++) {
         mpz_set_ui(va_gmp[i],i+1);
         mpz_powm(va_gmp[i],va_gmp[i],aux,p);   
    }
    uint8_t FermatFactor=0;
    for (uint32_t i=0;i<xgf_NUM_AB;i++) {
        if  ((i!=16)||(FermatFactor==0)){ // Avoid testing A = 8 B = 1 if it is a factor of 2 ^ (2 ^ M) +1
            uint32_t a=xgf_av[i]-1,b=xgf_bv[i]-1;
            mpz_add(aux,va_gmp[a],va_gmp[b]);
            if (mpz_cmp(aux,p)==0) {
                writeFactor(k,a+1,b+1,M,M-1,prime_prp);
                if (i==0) FermatFactor=1;
            } else {
                if (mpz_cmp(va_gmp[a],va_gmp[b])==0) {
                    test_xGF_gmp(k,M,a+1,b+1,prime_prp);  // there was excess power                              
                    if (i==0) FermatFactor=1;
                }                
            }
        }
    }
    mpz_clears(k,pm,aux,0);
    return 1;
}

