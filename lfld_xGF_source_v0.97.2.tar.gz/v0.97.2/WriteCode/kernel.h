#ifndef KERNEL_H
#define KERNEL_H


void WriteKernel(uint32_t nw);

#endif

