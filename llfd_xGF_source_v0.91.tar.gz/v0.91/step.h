void run_step(uint64_t kmax,uint32_t nmax);
