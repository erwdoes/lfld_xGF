#ifndef STR2UINT64_H
#define STR2UINT64_H

#include <stdint.h>

uint64_t str_2_uint64(const char *str);
char *uint64_2_str(char *str, uint64_t x);


#endif
