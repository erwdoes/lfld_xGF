#ifndef UINT642MPZ_H
#define UINT642MPZ_H

#include <stdint.h>
#include <gmp.h>

void mpz_set_ull(mpz_t n, uint64_t ull);
uint64_t mpz_get_ull(mpz_t n);


#endif //UINT642MPZ_H
